class_name Wanted
extends Node
# Six-star wanted system: witnesses, police response, recognition (name + vehicle), searches, arrests, trackers.

var heat := 0.0
var stars := 0
var recognized := false
var message := ""
var msg_t := 0.0
var pending: Array = []
var police: Array = []
var known_name := ""
var known_car: Car = null
var last_known := Vector3.ZERO
var has_last := false
var lost_t := 0.0
var arrest_t := 0.0
var spawn_t := 0.0
var search_t := 0.0
var tracked: Car = null
var tracker_t := 0.0
var tracker_name := ""


func say(m: String) -> void:
	message = m
	msg_t = 4.0


static func report(pos: Vector3, severity: float, loud: bool, who: Player, veh: Car) -> void:
	var g := Game.inst
	if g == null or g.wanted == null or who == null:
		return
	g.wanted.on_crime(pos, severity, loud, who, veh)


func on_crime(pos: Vector3, severity: float, loud: bool, who: Player, veh: Car) -> void:
	var witnesses := 0
	var rng := 30.0
	if loud:
		rng = 60.0
	for n in get_tree().get_nodes_in_group("peds"):
		var w := n as Walker
		if w == null:
			continue
		if w.global_position.distance_to(pos) <= rng:
			w.scare()
			if randf() < 0.85:
				witnesses += 1
	if witnesses == 0:
		say("No witnesses")
		return
	var sev := severity * minf(1.5, 0.7 + 0.3 * float(witnesses))
	var due := Time.get_ticks_msec() / 1000.0 + 3.5
	pending.append({"t": due, "sev": sev, "pos": pos, "who": who.char_name, "veh": veh})
	say("%d witness(es) calling the police" % witnesses)


func start_tracker(c: Car, who: Player) -> void:
	tracked = c
	tracker_t = 20.0
	tracker_name = who.char_name
	say("Stolen car has a tracker")


func police_target() -> Vector3:
	var h := Game.inst.hero
	if recognized or not has_last:
		return h.global_position
	return last_known


func _is_recognized(hero: Player, d: float) -> bool:
	if hero.char_name != known_name:
		return false
	if hero.car != null:
		return hero.car == known_car
	return d < 20.0


func _spawn_police(origin: Vector3) -> void:
	var pos := Vector3.ZERO
	var found := false
	for k in range(10):
		var n := City.node_pos(randi_range(0, City.N), randi_range(0, City.N))
		if n.distance_to(origin) < 110.0:
			continue
		pos = n
		found = true
		break
	if not found:
		return
	var c := Car.create_police(pos + Vector3(3.5, 0.2, 0.0))
	Game.inst.add_child(c)
	c.add_child(PoliceAI.new())
	police.append(c)


func _process(delta: float) -> void:
	if msg_t > 0.0:
		msg_t -= delta
	var hero := Game.inst.hero
	if hero == null:
		return
	var now := Time.get_ticks_msec() / 1000.0

	for i in range(pending.size() - 1, -1, -1):
		var d: Dictionary = pending[i]
		if now < float(d["t"]):
			continue
		pending.remove_at(i)
		heat = minf(6.0, heat + float(d["sev"]))
		known_name = d["who"]
		known_car = d["veh"]
		last_known = d["pos"]
		has_last = true
		lost_t = 0.0
		say("Police alerted: wanted level %d" % int(ceil(heat)))

	if tracked != null:
		if not is_instance_valid(tracked) or not tracked.has_tracker:
			tracked = null
		else:
			tracker_t -= delta
			if tracker_t <= 0.0:
				tracker_t = 8.0
				heat = maxf(heat, 1.0)
				known_car = tracked
				known_name = tracker_name
				last_known = tracked.global_position
				has_last = true
				say("Vehicle tracker pinged the police")

	stars = clampi(int(ceil(heat - 0.001)), 0, 6)
	if stars == 0:
		recognized = false
		return

	police = police.filter(func(p): return is_instance_valid(p))
	spawn_t -= delta
	if police.size() < stars and spawn_t <= 0.0:
		spawn_t = 3.5
		_spawn_police(hero.global_position)

	var rec := false
	var near := false
	for p in police:
		var pc := p as Car
		var dist := pc.global_position.distance_to(hero.global_position)
		if dist < 10.0:
			near = true
		if dist < 55.0 and _is_recognized(hero, dist):
			rec = true
	recognized = rec

	if rec:
		last_known = hero.global_position
		has_last = true
		lost_t = 0.0
	else:
		lost_t += delta

	if not rec and has_last:
		search_t -= delta
		var arrived := false
		for p in police:
			if (p as Car).global_position.distance_to(last_known) < 25.0:
				arrived = true
				break
		if arrived and search_t <= 0.0:
			search_t = 6.0
			var o := Vector2.from_angle(randf() * TAU) * randf_range(20.0, 70.0)
			var mx := City.N * City.PITCH
			last_known = Vector3(clampf(last_known.x + o.x, 0.0, mx), 0.0, clampf(last_known.z + o.y, 0.0, mx))

	if lost_t > 10.0:
		heat -= 0.07 * delta
	if heat <= 0.001:
		_clear("Wanted level cleared")
		return

	var still := false
	if hero.car != null:
		still = absf(hero.car.speed) < 2.0
	else:
		still = Inp.move.length() < 0.2
	if near and rec and still:
		arrest_t += delta
	else:
		arrest_t = maxf(0.0, arrest_t - delta)
	if arrest_t > 3.0:
		_busted(hero)


func _busted(hero: Player) -> void:
	hero.force_exit()
	hero.teleport(City.node_pos(City.N / 2, City.N / 2) + Vector3(6.0, 0.5, 14.0))
	_clear("BUSTED! Back at the station")


func _clear(msg: String) -> void:
	heat = 0.0
	stars = 0
	has_last = false
	lost_t = 0.0
	arrest_t = 0.0
	recognized = false
	for p in police:
		if is_instance_valid(p):
			var c := p as Car
			c.ai = false
			c.ai_in = Vector2.ZERO
			c.set_physics_process(true)
			get_tree().create_timer(10.0).timeout.connect(_free_car.bind(c))
	police.clear()
	say(msg)


func _free_car(c: Car) -> void:
	if is_instance_valid(c):
		c.queue_free()
