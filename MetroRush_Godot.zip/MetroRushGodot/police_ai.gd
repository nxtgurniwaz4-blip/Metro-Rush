class_name PoliceAI
extends Node
# Drives a police car along the road grid toward the target; goes direct when close; un-sticks itself.

var car: Car
var ci := 0
var cj := 0
var ti := 0
var tj := 0
var pdi := 0
var pdj := 0
var stuck := 0.0
var rev_t := 0.0


func _ready() -> void:
	car = get_parent() as Car
	car.ai = true
	var p := car.global_position
	ci = clampi(roundi(p.x / City.PITCH), 0, City.N)
	cj = clampi(roundi(p.z / City.PITCH), 0, City.N)
	ti = ci
	tj = cj


func _pick_next(tgt: Vector3) -> void:
	var dx := [1, -1, 0, 0]
	var dz := [0, 0, 1, -1]
	var best := 1.0e12
	var bi := -1
	for k in range(4):
		var ni: int = ci + dx[k]
		var nj: int = cj + dz[k]
		if ni < 0 or nj < 0 or ni > City.N or nj > City.N:
			continue
		if dx[k] == -pdi and dz[k] == -pdj:
			continue
		var d := City.node_pos(ni, nj).distance_squared_to(tgt) + randf()
		if d < best:
			best = d
			bi = k
	if bi < 0:
		pdi = -pdi
		pdj = -pdj
	else:
		pdi = dx[bi]
		pdj = dz[bi]
	ti = ci + pdi
	tj = cj + pdj


func _physics_process(delta: float) -> void:
	if car == null or not is_instance_valid(car):
		return
	var wt := Game.inst.wanted
	if wt == null or wt.stars == 0:
		car.ai_in = Vector2.ZERO
		return
	var tgt := wt.police_target()
	var me := car.global_position
	var wp := tgt
	if me.distance_to(tgt) >= 40.0:
		var np := City.node_pos(ti, tj)
		if me.distance_to(np) < 12.0:
			ci = ti
			cj = tj
			_pick_next(tgt)
			np = City.node_pos(ti, tj)
		wp = np
	var local := car.global_transform.affine_inverse() * wp
	var angle := rad_to_deg(atan2(local.x, -local.z))
	var steer := clampf(angle / 35.0, -1.0, 1.0)
	var maxs := 16.0 + 2.5 * float(wt.stars)
	if absf(angle) > 45.0:
		maxs *= 0.4
	var thr := 0.0
	if absf(car.speed) < maxs:
		thr = 1.0
	if absf(car.speed) < 0.8 and thr > 0.0:
		stuck += delta
	else:
		stuck = 0.0
	if stuck > 1.5:
		rev_t = 1.5
		stuck = 0.0
	if rev_t > 0.0:
		rev_t -= delta
		car.ai_in = Vector2(-steer, -1.0)
		return
	car.ai_in = Vector2(steer, thr)
