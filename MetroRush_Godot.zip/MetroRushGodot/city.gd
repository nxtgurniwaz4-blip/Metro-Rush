class_name City
extends RefCounted
# Whole city built with MultiMeshes (a handful of draw calls) + one static body for all solids.

const N := 8
const PITCH := 64.0
const ROAD := 14.0
const BLOCK := 50.0

static var building_mat: StandardMaterial3D
static var lamp_mat: StandardMaterial3D
static var vc_flat: StandardMaterial3D
static var _flat := {}
static var _glow := {}
static var _win_albedo: ImageTexture
static var _win_emit: ImageTexture

const PALETTE := [
	Color(0.90, 0.85, 0.80), Color(0.80, 0.85, 0.92), Color(0.88, 0.80, 0.80),
	Color(0.76, 0.78, 0.80), Color(0.95, 0.90, 0.76), Color(0.72, 0.77, 0.88),
	Color(0.88, 0.76, 0.70), Color(0.78, 0.88, 0.82)
]


static func node_pos(i: int, j: int) -> Vector3:
	return Vector3(i * PITCH, 0.0, j * PITCH)


static func flat(c: Color) -> StandardMaterial3D:
	if not _flat.has(c):
		var m := StandardMaterial3D.new()
		m.albedo_color = c
		m.roughness = 0.85
		_flat[c] = m
	return _flat[c]


static func glow(c: Color) -> StandardMaterial3D:
	if not _glow.has(c):
		var m := StandardMaterial3D.new()
		m.albedo_color = c
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		_glow[c] = m
	return _glow[c]


static func set_night(k: float) -> void:
	if building_mat != null:
		building_mat.emission_energy_multiplier = k * 1.6
	if lamp_mat != null:
		lamp_mat.albedo_color = Color(0.35, 0.35, 0.37).lerp(Color(1.0, 0.88, 0.55), k)


static func _make_window_textures() -> void:
	if _win_albedo != null:
		return
	var t := 128
	var a := Image.create(t, t, true, Image.FORMAT_RGBA8)
	var e := Image.create(t, t, true, Image.FORMAT_RGBA8)
	for wy in range(4):
		for wx in range(4):
			var lit := randf() < 0.45
			for y in range(32):
				for x in range(32):
					var wall := Color(0.93, 0.93, 0.95)
					var ecol := Color(0.0, 0.0, 0.0)
					if x >= 5 and x <= 26 and y >= 6 and y <= 26:
						wall = Color(0.55, 0.55, 0.58)
					if x >= 7 and x <= 24 and y >= 8 and y <= 24:
						wall = Color(0.26, 0.37, 0.55)
						if lit:
							ecol = Color(1.0, 0.82, 0.45)
					a.set_pixel(wx * 32 + x, wy * 32 + y, wall)
					e.set_pixel(wx * 32 + x, wy * 32 + y, ecol)
	a.generate_mipmaps()
	e.generate_mipmaps()
	_win_albedo = ImageTexture.create_from_image(a)
	_win_emit = ImageTexture.create_from_image(e)


static func _multi(parent: Node3D, items: Array, mesh: Mesh, mat: Material, shadows: bool) -> void:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = true
	mm.mesh = mesh
	mm.instance_count = items.size()
	for i in range(items.size()):
		var it: Array = items[i]
		var pos: Vector3 = it[0]
		var sz: Vector3 = it[1]
		var col: Color = it[2]
		mm.set_instance_transform(i, Transform3D(Basis.from_scale(sz), pos))
		mm.set_instance_color(i, col)
	var mi := MultiMeshInstance3D.new()
	mi.multimesh = mm
	mi.material_override = mat
	if not shadows:
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)


static func build(parent: Node3D) -> void:
	var root := Node3D.new()
	root.name = "City"
	parent.add_child(root)
	_make_window_textures()

	vc_flat = StandardMaterial3D.new()
	vc_flat.vertex_color_use_as_albedo = true
	vc_flat.roughness = 0.9

	building_mat = StandardMaterial3D.new()
	building_mat.vertex_color_use_as_albedo = true
	building_mat.albedo_texture = _win_albedo
	building_mat.uv1_triplanar = true
	building_mat.uv1_world_triplanar = true
	building_mat.uv1_scale = Vector3(0.0625, 0.0625, 0.0625)
	building_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	building_mat.emission_enabled = true
	building_mat.emission_texture = _win_emit
	building_mat.emission_energy_multiplier = 0.0
	building_mat.roughness = 0.8

	lamp_mat = StandardMaterial3D.new()
	lamp_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	lamp_mat.albedo_color = Color(0.35, 0.35, 0.37)

	var size: float = N * PITCH
	var solid := StaticBody3D.new()
	root.add_child(solid)

	# ground
	var gm := MeshInstance3D.new()
	var gb := BoxMesh.new()
	gb.size = Vector3(size + 700.0, 1.0, size + 700.0)
	gm.mesh = gb
	gm.material_override = flat(Color(0.30, 0.42, 0.27))
	gm.position = Vector3(size / 2.0, -0.5, size / 2.0)
	gm.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(gm)
	var gcs := CollisionShape3D.new()
	var gsh := BoxShape3D.new()
	gsh.size = gb.size
	gcs.shape = gsh
	gcs.position = gm.position
	solid.add_child(gcs)

	var asphalt := Color(0.16, 0.16, 0.18)
	var yellow := Color(0.95, 0.80, 0.15)
	var white := Color(0.92, 0.92, 0.92)
	var roads := []
	var dashes := []
	var cross := []
	var poles := []
	var heads := []
	for i in range(N + 1):
		roads.append([Vector3(i * PITCH, 0.0, size / 2.0), Vector3(ROAD, 0.1, size + ROAD), asphalt])
		roads.append([Vector3(size / 2.0, 0.0, i * PITCH), Vector3(size + ROAD, 0.1, ROAD), asphalt])
		for k in range(int(size / 8.0)):
			var d: float = k * 8.0 + 4.0
			var m := fposmod(d, PITCH)
			if m < 10.0 or m > PITCH - 10.0:
				continue
			dashes.append([Vector3(i * PITCH, 0.055, d), Vector3(0.25, 0.02, 3.0), yellow])
			dashes.append([Vector3(d, 0.056, i * PITCH), Vector3(3.0, 0.02, 0.25), yellow])

	# crosswalks + street lamps at every junction
	for i in range(N + 1):
		for j in range(N + 1):
			var x: float = i * PITCH
			var z: float = j * PITCH
			for s in range(9):
				var off: float = -5.6 + s * 1.4
				if j > 0:
					cross.append([Vector3(x + off, 0.056, z - 9.5), Vector3(0.6, 0.02, 3.0), white])
				if j < N:
					cross.append([Vector3(x + off, 0.056, z + 9.5), Vector3(0.6, 0.02, 3.0), white])
				if i > 0:
					cross.append([Vector3(x - 9.5, 0.056, z + off), Vector3(3.0, 0.02, 0.6), white])
				if i < N:
					cross.append([Vector3(x + 9.5, 0.056, z + off), Vector3(3.0, 0.02, 0.6), white])
			for sx in [-8.5, 8.5]:
				for sz in [-8.5, 8.5]:
					poles.append([Vector3(x + sx, 3.5, z + sz), Vector3(0.2, 7.0, 0.2), Color(0.3, 0.3, 0.32)])
					heads.append([Vector3(x + sx, 7.1, z + sz), Vector3(0.7, 0.25, 0.7), Color.WHITE])

	var walks := []
	var grass := []
	var bldgs := []
	var trunks := []
	var leaves := []
	for i in range(N):
		for j in range(N):
			var cx: float = (i + 0.5) * PITCH
			var cz: float = (j + 0.5) * PITCH
			walks.append([Vector3(cx, 0.0, cz), Vector3(BLOCK, 0.06, BLOCK), Color(0.62, 0.62, 0.64)])
			if randf() < 0.12:
				grass.append([Vector3(cx, 0.0, cz), Vector3(42.0, 0.08, 42.0), Color(0.28, 0.52, 0.25)])
				for k in range(8):
					var tx: float = cx + randf_range(-18.0, 18.0)
					var tz: float = cz + randf_range(-18.0, 18.0)
					trunks.append([Vector3(tx, 1.5, tz), Vector3(0.5, 3.0, 0.5), Color(0.35, 0.22, 0.12)])
					var ld: float = randf_range(3.6, 5.6)
					leaves.append([Vector3(tx, 4.6, tz), Vector3(ld, ld, ld), Color(0.12, randf_range(0.40, 0.55), 0.15)])
				continue
			for ox in [-10.5, 10.5]:
				for oz in [-10.5, 10.5]:
					var w: float = randf_range(15.0, 19.0)
					var d: float = randf_range(15.0, 19.0)
					var h: float = randf_range(10.0, 38.0)
					if randf() < 0.15:
						h = randf_range(45.0, 95.0)
					var col: Color = PALETTE[randi() % PALETTE.size()]
					bldgs.append([Vector3(cx + ox, h / 2.0, cz + oz), Vector3(w, h, d), col])

	var unit_box := BoxMesh.new()
	unit_box.size = Vector3.ONE
	var unit_sphere := SphereMesh.new()
	unit_sphere.radius = 0.5
	unit_sphere.height = 1.0
	unit_sphere.radial_segments = 10
	unit_sphere.rings = 5

	_multi(root, roads, unit_box, vc_flat, false)
	_multi(root, walks, unit_box, vc_flat, false)
	_multi(root, grass, unit_box, vc_flat, false)
	_multi(root, dashes, unit_box, vc_flat, false)
	_multi(root, cross, unit_box, vc_flat, false)
	_multi(root, poles, unit_box, vc_flat, false)
	_multi(root, heads, unit_box, lamp_mat, false)
	_multi(root, trunks, unit_box, vc_flat, false)
	_multi(root, leaves, unit_sphere, vc_flat, false)
	_multi(root, bldgs, unit_box, building_mat, true)

	for b in bldgs:
		var cs := CollisionShape3D.new()
		var sh := BoxShape3D.new()
		sh.size = b[1]
		cs.shape = sh
		cs.position = b[0]
		solid.add_child(cs)
