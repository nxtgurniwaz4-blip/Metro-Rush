class_name City
extends RefCounted

const N := 8
const PITCH := 64.0
const ROAD := 14.0
const BLOCK := 50.0

static var _flat := {}
static var _glow := {}
static var _bld := {}
static var _win_tex: ImageTexture

const PALETTE := [
	Color(0.90, 0.85, 0.80), Color(0.80, 0.85, 0.92), Color(0.88, 0.80, 0.80),
	Color(0.76, 0.78, 0.80), Color(0.95, 0.90, 0.76), Color(0.72, 0.77, 0.88),
	Color(0.88, 0.76, 0.70), Color(0.78, 0.88, 0.82)
]


static func node_pos(i: int, j: int) -> Vector3:
	return Vector3(i * PITCH, 0.0, j * PITCH)


static func flat(c: Color) -> StandardMaterial3D:
	if not _flat.has(c):
		var m := StandardMaterial3D.new()
		m.albedo_color = c
		m.roughness = 0.9
		_flat[c] = m
	return _flat[c]


static func glow(c: Color) -> StandardMaterial3D:
	if not _glow.has(c):
		var m := StandardMaterial3D.new()
		m.albedo_color = c
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		_glow[c] = m
	return _glow[c]


static func _window_tex() -> ImageTexture:
	if _win_tex != null:
		return _win_tex
	var img := Image.create(32, 32, true, Image.FORMAT_RGBA8)
	for y in range(32):
		for x in range(32):
			var col := Color(0.93, 0.93, 0.95)
			if x >= 5 and x <= 26 and y >= 6 and y <= 26:
				col = Color(0.55, 0.55, 0.58)
			if x >= 6 and x <= 25 and y >= 7 and y <= 25:
				col = Color(0.26, 0.37, 0.55)
			img.set_pixel(x, y, col)
	img.generate_mipmaps()
	_win_tex = ImageTexture.create_from_image(img)
	return _win_tex


static func building_mat(c: Color) -> StandardMaterial3D:
	if not _bld.has(c):
		var m := StandardMaterial3D.new()
		m.albedo_color = c
		m.albedo_texture = _window_tex()
		m.uv1_triplanar = true
		m.uv1_world_triplanar = true
		m.uv1_scale = Vector3(0.25, 0.25, 0.25)
		m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
		m.roughness = 0.8
		_bld[c] = m
	return _bld[c]


static func box(parent: Node3D, pos: Vector3, size: Vector3, mat: Material, collide: bool) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)
	if collide:
		var sb := StaticBody3D.new()
		var cs := CollisionShape3D.new()
		var sh := BoxShape3D.new()
		sh.size = size
		cs.shape = sh
		sb.add_child(cs)
		mi.add_child(sb)
	return mi


static func build(parent: Node3D) -> void:
	var root := Node3D.new()
	root.name = "City"
	parent.add_child(root)
	var size: float = N * PITCH

	# ground (top surface at y = 0)
	box(root, Vector3(size / 2.0, -0.5, size / 2.0), Vector3(size + 700.0, 1.0, size + 700.0), flat(Color(0.30, 0.42, 0.27)), true)

	var asphalt := flat(Color(0.16, 0.16, 0.18))
	for i in range(N + 1):
		box(root, Vector3(i * PITCH, 0.0, size / 2.0), Vector3(ROAD, 0.1, size + ROAD), asphalt, false)
		box(root, Vector3(size / 2.0, 0.0, i * PITCH), Vector3(size + ROAD, 0.1, ROAD), asphalt, false)

	var walk := flat(Color(0.62, 0.62, 0.64))
	var grass := flat(Color(0.28, 0.52, 0.25))
	var trunk := flat(Color(0.35, 0.22, 0.12))
	var offs := [-10.5, 10.5]

	for i in range(N):
		for j in range(N):
			var cx: float = (i + 0.5) * PITCH
			var cz: float = (j + 0.5) * PITCH
			box(root, Vector3(cx, 0.0, cz), Vector3(BLOCK, 0.06, BLOCK), walk, false)

			if randf() < 0.12:
				box(root, Vector3(cx, 0.0, cz), Vector3(42.0, 0.08, 42.0), grass, false)
				for k in range(7):
					var tx: float = cx + randf_range(-18.0, 18.0)
					var tz: float = cz + randf_range(-18.0, 18.0)
					var tm := MeshInstance3D.new()
					var cyl := CylinderMesh.new()
					cyl.top_radius = 0.25
					cyl.bottom_radius = 0.3
					cyl.height = 3.0
					cyl.radial_segments = 8
					tm.mesh = cyl
					tm.material_override = trunk
					tm.position = Vector3(tx, 1.5, tz)
					root.add_child(tm)
					var lm := MeshInstance3D.new()
					var sp := SphereMesh.new()
					var rad: float = randf_range(1.8, 2.8)
					sp.radius = rad
					sp.height = rad * 2.0
					sp.radial_segments = 10
					sp.rings = 6
					lm.mesh = sp
					lm.material_override = flat(Color(0.12, randf_range(0.40, 0.55), 0.15))
					lm.position = Vector3(tx, 4.6, tz)
					root.add_child(lm)
				continue

			for ox in offs:
				for oz in offs:
					var w: float = randf_range(15.0, 19.0)
					var d: float = randf_range(15.0, 19.0)
					var h: float = randf_range(45.0, 95.0) if randf() < 0.15 else randf_range(10.0, 38.0)
					var mat := building_mat(PALETTE[randi() % PALETTE.size()])
					var b := box(root, Vector3(cx + ox, h / 2.0, cz + oz), Vector3(w, h, d), mat, true)
					b.visibility_range_end = 420.0
