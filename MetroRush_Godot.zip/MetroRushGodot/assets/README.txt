Drop-in models (optional). Put .glb (or .gltf) files in this folder:
  car*.glb         -> every car (a random one per car; scaled to car length automatically)
  adams*.glb       -> the male protagonist (animated: needs "walk"/"idle" animations)
  eve*.glb         -> the female protagonist
  char*.glb        -> used for Adams/Eve if no adams*/eve* file exists
  ped*.glb         -> pedestrians
Add "_flip" to a file name (e.g. car1_flip.glb) to turn it 180 degrees if it drives/walks backwards.
Without any files here the game uses its built-in shapes.
