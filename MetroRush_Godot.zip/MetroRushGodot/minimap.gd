class_name MiniMap
extends Control
# Minimap drawn directly from the city grid (no extra 3D rendering).

const VIEW := 230.0


func _ready() -> void:
	clip_contents = true
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func _process(_d: float) -> void:
	queue_redraw()


func _draw() -> void:
	var g := Game.inst
	if g == null or g.hero == null:
		return
	var hp := g.hero.global_position
	var k := size.x / VIEW
	var c := size * 0.5
	var u := size.x / 260.0
	var span := City.N * City.PITCH
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.18, 0.28, 0.17))

	for i in range(City.N + 1):
		var x: float = i * City.PITCH
		draw_line(c + Vector2(x - hp.x, -hp.z) * k, c + Vector2(x - hp.x, span - hp.z) * k, Color(0.12, 0.12, 0.14), City.ROAD * k)
		draw_line(c + Vector2(-hp.x, x - hp.z) * k, c + Vector2(span - hp.x, x - hp.z) * k, Color(0.12, 0.12, 0.14), City.ROAD * k)

	var bs := City.BLOCK * k
	for i in range(City.N):
		for j in range(City.N):
			var p := c + Vector2((i + 0.5) * City.PITCH - hp.x, (j + 0.5) * City.PITCH - hp.z) * k
			if p.x < -bs or p.y < -bs or p.x > size.x + bs or p.y > size.y + bs:
				continue
			draw_rect(Rect2(p - Vector2(bs, bs) * 0.5, Vector2(bs, bs)), Color(0.50, 0.50, 0.53))

	for n in get_tree().get_nodes_in_group("cars"):
		var car := n as Node3D
		var cp := c + Vector2(car.global_position.x - hp.x, car.global_position.z - hp.z) * k
		draw_circle(cp, 4.0 * u, Color(0.3, 0.6, 1.0))
	for n in get_tree().get_nodes_in_group("traffic"):
		var tr := n as Node3D
		var tp := c + Vector2(tr.global_position.x - hp.x, tr.global_position.z - hp.z) * k
		draw_circle(tp, 3.0 * u, Color(0.8, 0.8, 0.8))

	var yaw := g.hero.rotation.y
	if g.hero.car != null:
		yaw = g.hero.car.rotation.y
	var fwd := Vector2(-sin(yaw), -cos(yaw))
	var rgt := Vector2(-fwd.y, fwd.x)
	var pts := PackedVector2Array([c + fwd * 13.0 * u, c - fwd * 8.0 * u + rgt * 8.0 * u, c - fwd * 8.0 * u - rgt * 8.0 * u])
	draw_colored_polygon(pts, Color(1.0, 0.3, 0.2))
