class_name Player
extends CharacterBody3D

var char_name := ""
var active := false
var car: Car = null
var visual: Node3D
var shape: CollisionShape3D


static func create(nm: String, turban: Color, outfit: Color, pos: Vector3) -> Player:
	var p := Player.new()
	p.char_name = nm
	p.position = pos
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 1.8
	cs.shape = cap
	cs.position = Vector3(0.0, 0.9, 0.0)
	p.add_child(cs)
	p.shape = cs

	var vis := Node3D.new()
	p.add_child(vis)
	p.visual = vis

	var body := MeshInstance3D.new()
	var cm := CapsuleMesh.new()
	cm.radius = 0.4
	cm.height = 1.8
	cm.radial_segments = 16
	cm.rings = 6
	body.mesh = cm
	body.material_override = City.flat(outfit)
	body.position = Vector3(0.0, 0.9, 0.0)
	vis.add_child(body)

	# dastar (turban)
	var tm := MeshInstance3D.new()
	var tsp := SphereMesh.new()
	tsp.radius = 0.34
	tsp.height = 0.55
	tsp.radial_segments = 16
	tsp.rings = 8
	tm.mesh = tsp
	tm.material_override = City.flat(turban)
	tm.position = Vector3(0.0, 1.72, 0.0)
	vis.add_child(tm)

	# beard
	var bm := MeshInstance3D.new()
	var bsp := SphereMesh.new()
	bsp.radius = 0.2
	bsp.height = 0.34
	bsp.radial_segments = 12
	bsp.rings = 6
	bm.mesh = bsp
	bm.material_override = City.flat(Color(0.12, 0.10, 0.10))
	bm.position = Vector3(0.0, 1.5, -0.22)
	vis.add_child(bm)
	return p


func _process(_d: float) -> void:
	if not active:
		return
	if Inp.enter_pressed:
		Inp.enter_pressed = false
		if car != null:
			exit_car()
		else:
			try_enter()


func try_enter() -> void:
	var best: Car = null
	var bd := 5.0
	for n in get_tree().get_nodes_in_group("cars"):
		var c: Car = n as Car
		if c == null:
			continue
		var d := c.global_position.distance_to(global_position)
		if d < bd:
			bd = d
			best = c
	if best == null:
		return
	car = best
	best.driven = true
	shape.set_deferred("disabled", true)
	visual.visible = false
	Game.inst.cam.set_target(best, 9.0)


func exit_car() -> void:
	if car == null:
		return
	var out := car.global_position - car.global_transform.basis.x * 2.6 + Vector3.UP * 0.4
	car.driven = false
	car = null
	global_position = out
	velocity = Vector3.ZERO
	shape.set_deferred("disabled", false)
	visual.visible = true
	if active:
		Game.inst.cam.set_target(self, 5.5)


func force_exit() -> void:
	if car != null:
		exit_car()


func _physics_process(delta: float) -> void:
	if car != null:
		global_position = car.global_position
		return
	var dir := Vector3.ZERO
	if active:
		var yaw: float = Game.inst.cam.yaw
		var fwd := Vector3(-sin(yaw), 0.0, -cos(yaw))
		var right := Vector3(cos(yaw), 0.0, -sin(yaw))
		dir = fwd * Inp.move.y + right * Inp.move.x
		if dir.length() > 1.0:
			dir = dir.normalized()
	var spd := 3.8
	if Inp.move.length() > 0.8:
		spd = 7.0
	if dir.length() > 0.05:
		rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), 12.0 * delta)
	velocity.x = dir.x * spd
	velocity.z = dir.z * spd
	if is_on_floor():
		velocity.y = -1.0
	else:
		velocity.y -= 25.0 * delta
	move_and_slide()
