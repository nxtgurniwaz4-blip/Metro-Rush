class_name Player
extends CharacterBody3D

var char_name := ""
var active := false
var car: Car = null
var visual: Node3D
var shape: CollisionShape3D
var parts := {}
var walk_t := 0.0
var pick := LockPick.new()
var anim: AnimationPlayer
var walk_name := ""
var idle_name := ""
var prev_brake := false


static func create(nm: String, female: bool, pos: Vector3) -> Player:
	var p := Player.new()
	p.char_name = nm
	p.position = pos
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 1.8
	cs.shape = cap
	cs.position = Vector3(0.0, 0.9, 0.0)
	p.add_child(cs)
	p.shape = cs
	var vis := Node3D.new()
	p.add_child(vis)
	p.visual = vis
	var afiles := Assets.files(nm.to_lower())
	if afiles.is_empty():
		var anyc := Assets.files("char")
		if anyc.size() > 0:
			afiles.append(anyc[(1 if female else 0) % anyc.size()])
	if afiles.size() > 0:
		var am := Assets.instance(afiles[0], 1.8, true)
		if am != null:
			vis.add_child(am)
			p.anim = Assets.find_anim(am)
			if p.anim != null:
				p.walk_name = Assets.pick_anim(p.anim, ["walk", "run"])
				p.idle_name = Assets.pick_anim(p.anim, ["idle", "stand"])
				Assets.loop(p.anim, p.walk_name)
				Assets.loop(p.anim, p.idle_name)
			return p
	if female:
		p.parts = Human.build(vis, Color(0.80, 0.18, 0.25), Color(0.10, 0.10, 0.12), Color(0.90, 0.72, 0.60), Color(0.80, 0.62, 0.30), true)
	else:
		p.parts = Human.build(vis, Color(0.20, 0.35, 0.70), Color(0.15, 0.17, 0.25), Color(0.80, 0.60, 0.45), Color(0.20, 0.12, 0.08), false)
	return p


func _process(delta: float) -> void:
	_animate(delta)
	if not active:
		return
	if pick.active:
		var smash := Inp.brake and not prev_brake
		prev_brake = Inp.brake
		var tc := pick.target
		if smash and tc != null:
			pick.active = false
			tc.locked = false
			if tc.security >= 2:
				tc.start_alarm()
			_enter(tc, 1.3, true)
			return
		var r := pick.tick(delta, global_position)
		if r == 1 and tc != null:
			tc.locked = false
			_enter(tc, 1.0, false)
		return
	prev_brake = Inp.brake
	if Inp.enter_pressed:
		Inp.enter_pressed = false
		if car != null:
			exit_car()
		else:
			try_enter()


func _animate(delta: float) -> void:
	var sp := Vector2(velocity.x, velocity.z).length()
	if car != null:
		sp = 0.0
	if anim != null:
		var want := idle_name
		if sp > 0.3:
			want = walk_name
		if want != "" and anim.current_animation != want:
			anim.play(want, 0.2)
		if sp > 0.3:
			anim.speed_scale = clampf(sp / 3.0, 0.7, 2.2)
		else:
			anim.speed_scale = 1.0
		return
	if parts.is_empty():
		return
	var amp := clampf(sp / 4.0, 0.0, 1.4) * 0.8
	if sp > 0.2:
		walk_t += delta * (6.0 + sp * 0.8)
	var sw := sin(walk_t) * amp
	(parts["leg_l"] as Node3D).rotation.x = sw
	(parts["leg_r"] as Node3D).rotation.x = -sw
	(parts["arm_l"] as Node3D).rotation.x = -sw
	(parts["arm_r"] as Node3D).rotation.x = sw


func try_enter() -> void:
	var best: Car = null
	var bd := 5.0
	for n in get_tree().get_nodes_in_group("cars"):
		var c: Car = n as Car
		if c == null:
			continue
		var d := c.global_position.distance_to(global_position)
		if d < bd:
			bd = d
			best = c
	var tw: Walker = null
	var td := 4.0
	for n in get_tree().get_nodes_in_group("traffic"):
		var w := n as Walker
		if w == null:
			continue
		var wd := w.global_position.distance_to(global_position)
		if wd < td:
			td = wd
			tw = w
	if tw != null and (best == null or td < bd):
		_carjack(tw)
		return
	if best == null:
		return
	if best.locked:
		pick.begin(best)
		return
	var sev := 0.6
	if best.owned:
		sev = 0.0
	_enter(best, sev, false)


func _carjack(w: Walker) -> void:
	var c := Car.create(w.global_position + Vector3.UP * 0.2, w.rotation.y, w.color, 1)
	c.locked = false
	Game.inst.add_child(c)
	w.queue_free()
	_enter(c, 2.0, true)


func _enter(c: Car, severity: float, loud: bool) -> void:
	car = c
	c.driven = true
	c.set_physics_process(true)
	shape.set_deferred("disabled", true)
	visual.visible = false
	Game.inst.cam.set_target(c, 9.0)
	if not c.owned and severity > 0.0:
		c.stolen = true
		Wanted.report(c.global_position, severity, loud, self, c)
		if c.has_tracker:
			Game.inst.wanted.start_tracker(c, self)


func teleport(p: Vector3) -> void:
	global_position = p
	velocity = Vector3.ZERO


func exit_car() -> void:
	if car == null:
		return
	var out := car.global_position - car.global_transform.basis.x * 2.6 + Vector3.UP * 0.4
	car.driven = false
	car = null
	global_position = out
	velocity = Vector3.ZERO
	shape.set_deferred("disabled", false)
	visual.visible = true
	if active:
		Game.inst.cam.set_target(self, 5.5)


func force_exit() -> void:
	if car != null:
		exit_car()


func _physics_process(delta: float) -> void:
	if car != null:
		global_position = car.global_position
		return
	var dir := Vector3.ZERO
	if active and not pick.active:
		var yaw: float = Game.inst.cam.yaw
		var fwd := Vector3(-sin(yaw), 0.0, -cos(yaw))
		var right := Vector3(cos(yaw), 0.0, -sin(yaw))
		dir = fwd * Inp.move.y + right * Inp.move.x
		if dir.length() > 1.0:
			dir = dir.normalized()
	var spd := 3.8
	if Inp.move.length() > 0.8:
		spd = 7.0
	if dir.length() > 0.05:
		rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), 12.0 * delta)
	velocity.x = dir.x * spd
	velocity.z = dir.z * spd
	if is_on_floor():
		velocity.y = -1.0
	else:
		velocity.y -= 25.0 * delta
	move_and_slide()
