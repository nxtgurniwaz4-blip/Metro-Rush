class_name Player
extends CharacterBody3D

var char_name := ""
var active := false
var car: Car = null
var visual: Node3D
var shape: CollisionShape3D
var parts := {}
var walk_t := 0.0


static func create(nm: String, female: bool, pos: Vector3) -> Player:
	var p := Player.new()
	p.char_name = nm
	p.position = pos
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 1.8
	cs.shape = cap
	cs.position = Vector3(0.0, 0.9, 0.0)
	p.add_child(cs)
	p.shape = cs
	var vis := Node3D.new()
	p.add_child(vis)
	p.visual = vis
	if female:
		p.parts = Human.build(vis, Color(0.80, 0.18, 0.25), Color(0.10, 0.10, 0.12), Color(0.90, 0.72, 0.60), Color(0.80, 0.62, 0.30), true)
	else:
		p.parts = Human.build(vis, Color(0.20, 0.35, 0.70), Color(0.15, 0.17, 0.25), Color(0.80, 0.60, 0.45), Color(0.20, 0.12, 0.08), false)
	return p


func _process(delta: float) -> void:
	_animate(delta)
	if not active:
		return
	if Inp.enter_pressed:
		Inp.enter_pressed = false
		if car != null:
			exit_car()
		else:
			try_enter()


func _animate(delta: float) -> void:
	var sp := Vector2(velocity.x, velocity.z).length()
	if car != null:
		sp = 0.0
	var amp := clampf(sp / 4.0, 0.0, 1.4) * 0.8
	if sp > 0.2:
		walk_t += delta * (6.0 + sp * 0.8)
	var sw := sin(walk_t) * amp
	(parts["leg_l"] as Node3D).rotation.x = sw
	(parts["leg_r"] as Node3D).rotation.x = -sw
	(parts["arm_l"] as Node3D).rotation.x = -sw
	(parts["arm_r"] as Node3D).rotation.x = sw


func try_enter() -> void:
	var best: Car = null
	var bd := 5.0
	for n in get_tree().get_nodes_in_group("cars"):
		var c: Car = n as Car
		if c == null:
			continue
		var d := c.global_position.distance_to(global_position)
		if d < bd:
			bd = d
			best = c
	if best == null:
		return
	car = best
	best.driven = true
	shape.set_deferred("disabled", true)
	visual.visible = false
	Game.inst.cam.set_target(best, 9.0)


func exit_car() -> void:
	if car == null:
		return
	var out := car.global_position - car.global_transform.basis.x * 2.6 + Vector3.UP * 0.4
	car.driven = false
	car = null
	global_position = out
	velocity = Vector3.ZERO
	shape.set_deferred("disabled", false)
	visual.visible = true
	if active:
		Game.inst.cam.set_target(self, 5.5)


func force_exit() -> void:
	if car != null:
		exit_car()


func _physics_process(delta: float) -> void:
	if car != null:
		global_position = car.global_position
		return
	var dir := Vector3.ZERO
	if active:
		var yaw: float = Game.inst.cam.yaw
		var fwd := Vector3(-sin(yaw), 0.0, -cos(yaw))
		var right := Vector3(cos(yaw), 0.0, -sin(yaw))
		dir = fwd * Inp.move.y + right * Inp.move.x
		if dir.length() > 1.0:
			dir = dir.normalized()
	var spd := 3.8
	if Inp.move.length() > 0.8:
		spd = 7.0
	if dir.length() > 0.05:
		rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), 12.0 * delta)
	velocity.x = dir.x * spd
	velocity.z = dir.z * spd
	if is_on_floor():
		velocity.y = -1.0
	else:
		velocity.y -= 25.0 * delta
	move_and_slide()
