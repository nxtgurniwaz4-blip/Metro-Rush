class_name EngineSound
extends AudioStreamPlayer
# Procedural engine hum whose pitch follows the car's speed.

var phase := 0.0
var rate := 22050.0


func _ready() -> void:
	var gen := AudioStreamGenerator.new()
	gen.mix_rate = rate
	gen.buffer_length = 0.12
	stream = gen
	volume_db = -6.0
	play()


func _process(_d: float) -> void:
	var pb := get_stream_playback() as AudioStreamGeneratorPlayback
	if pb == null:
		return
	var g := Game.inst
	var amp := 0.0
	var sp := 0.0
	if g != null and g.hero != null and g.hero.car != null:
		amp = 0.16
		sp = absf(g.hero.car.speed)
	var freq := 55.0 + sp * 5.5
	var n := pb.get_frames_available()
	for i in range(n):
		phase += freq / rate
		if phase > 1.0:
			phase -= 1.0
		var v := (sin(phase * TAU) + 0.5 * sin(phase * TAU * 2.0) + 0.25 * sin(phase * TAU * 3.0)) * amp
		pb.push_frame(Vector2(v, v))
