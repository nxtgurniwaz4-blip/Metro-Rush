class_name Game
extends Node3D

static var inst: Game

var hero: Player
var players: Array[Player] = []
var cam: OrbitCam
var hud: Hud
var sun: DirectionalLight3D
var env: Environment
var sky_mat: ProceduralSkyMaterial
var sky_timer := 0.0
var hour := 10.0
var is_night := false
var wanted: Wanted
var res_scale := 1.0
var perf_t := 1.0
var good_s := 0


func _ready() -> void:
	inst = self
	randomize()
	Engine.max_fps = 60
	DisplayServer.screen_set_keep_on(true)

	var we := WorldEnvironment.new()
	env = Environment.new()
	sky_mat = ProceduralSkyMaterial.new()
	var sky := Sky.new()
	sky.sky_material = sky_mat
	sky.radiance_size = Sky.RADIANCE_SIZE_32
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.reflected_light_source = Environment.REFLECTION_SOURCE_DISABLED
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.5, 0.54, 0.62)
	env.ambient_light_energy = 1.0
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color(0.7, 0.82, 0.95)
	env.fog_density = 0.003
	env.adjustment_enabled = true
	env.adjustment_contrast = 1.12
	env.adjustment_saturation = 0.82
	env.glow_enabled = true
	env.glow_intensity = 0.6
	env.glow_hdr_threshold = 0.9
	get_viewport().screen_space_aa = Viewport.SCREEN_SPACE_AA_FXAA
	we.environment = env
	add_child(we)

	sun = DirectionalLight3D.new()
	sun.shadow_enabled = true
	sun.light_color = Color(1.0, 0.95, 0.85)
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
	sun.directional_shadow_max_distance = 70.0
	add_child(sun)

	City.build(self)

	cam = OrbitCam.new()
	cam.far = 600.0
	cam.fov = 62.0
	add_child(cam)
	cam.current = true

	var colors := [
		Color(0.80, 0.12, 0.12), Color(0.12, 0.30, 0.75), Color(0.92, 0.92, 0.92),
		Color(0.95, 0.75, 0.10), Color(0.10, 0.10, 0.12), Color(0.95, 0.45, 0.10),
		Color(0.15, 0.55, 0.35)
	]

	# two protagonists: Adams (male) and Eve (female), each with a personal car
	var c := City.node_pos(City.N / 2, City.N / 2)
	var adams := Player.create("Adams", false, c + Vector3(0.5, 0.2, 20.0))
	var eve := Player.create("Eve", true, c + Vector3(0.5, 0.2, -20.0))
	add_child(adams)
	add_child(eve)
	players.append(adams)
	players.append(eve)
	hero = adams
	adams.active = true
	cam.set_target(adams, 5.5)

	var v1 := Car.create(c + Vector3(6.0, 0.2, 22.0), 0.0, colors[0], 0)
	v1.owned = true
	add_child(v1)
	var v2 := Car.create(c + Vector3(6.0, 0.2, -22.0), 0.0, colors[2], 0)
	v2.owned = true
	add_child(v2)

	var used: Array[Vector3] = [c + Vector3(6.0, 0.2, 22.0), c + Vector3(6.0, 0.2, -22.0)]
	var made := 0
	var tries := 0
	while made < 16 and tries < 300:
		tries += 1
		var pi: int = randi_range(0, City.N)
		var pj: int = randi_range(0, City.N - 1)
		var pos := Vector3(pi * City.PITCH + 6.0, 0.2, pj * City.PITCH + randf_range(14.0, 50.0))
		var clear := true
		for u in used:
			if u.distance_to(pos) < 8.0:
				clear = false
				break
		if not clear:
			continue
		used.append(pos)
		add_child(Car.create(pos, 0.0, colors[randi() % colors.size()]))
		made += 1

	# traffic: one draw call per car
	for k in range(30):
		var w := Walker.new()
		w.speed = 10.0
		w.lateral = 3.5
		w.height = 0.05
		var cs := CollisionShape3D.new()
		var sh := BoxShape3D.new()
		sh.size = Vector3(1.9, 1.2, 4.2)
		cs.shape = sh
		cs.position = Vector3(0.0, 0.6, 0.0)
		w.add_child(cs)
		var col: Color = colors[randi() % colors.size()]
		var tmi := Car.add_visual(w, col, false, [], [])
		Assets.set_vis_range(tmi, 260.0)
		w.color = col
		w.add_to_group("traffic")
		add_child(w)
		w.start_walk()

	# pedestrians: one draw call each, with a walking bob
	for k in range(60):
		var w := Walker.new()
		w.is_ped = true
		w.add_to_group("peds")
		w.speed = randf_range(1.2, 1.9)
		w.lateral = 9.0
		w.height = 0.0
		var vis := Node3D.new()
		w.add_child(vis)
		var pfiles := Assets.files("ped")
		var pm: Node3D = null
		if pfiles.size() > 0:
			pm = Assets.instance(pfiles[randi() % pfiles.size()], 1.7, true)
		if pm != null:
			vis.add_child(pm)
			var pap := Assets.find_anim(pm)
			if pap != null:
				var wn := Assets.pick_anim(pap, ["walk"])
				if wn != "":
					Assets.loop(pap, wn)
					pap.play(wn)
					pap.speed_scale = 0.9
			Assets.set_vis_range(pm, 220.0)
		else:
			var mi := MeshInstance3D.new()
			mi.mesh = MeshKit.ped_mesh(Color.from_hsv(randf(), 0.55, 0.8), Color.from_hsv(randf(), 0.3, 0.3), Color(0.85, 0.66, 0.5), Color(0.2, 0.14, 0.1))
			mi.material_override = MeshKit.shared_vc()
			mi.visibility_range_end = 220.0
			vis.add_child(mi)
		w.visual = vis
		add_child(w)
		w.start_walk()

	add_child(EngineSound.new())

	wanted = Wanted.new()
	add_child(wanted)

	var layer := CanvasLayer.new()
	add_child(layer)
	hud = Hud.new()
	layer.add_child(hud)


func switch_hero() -> void:
	var other: Player = players[1]
	if hero == players[1]:
		other = players[0]
	hero.force_exit()
	hero.active = false
	other.active = true
	hero = other
	cam.set_target(other, 5.5)


func _process(delta: float) -> void:
	if Inp.switch_pressed:
		Inp.switch_pressed = false
		switch_hero()

	hour = fposmod(hour + delta * (24.0 / 720.0), 24.0)
	var sn := sin((hour - 6.0) / 24.0 * TAU)
	var day := clampf((sn + 0.15) / 0.5, 0.0, 1.0)
	var dusk := clampf(1.0 - absf(sn) / 0.3, 0.0, 1.0)
	var horizon := Color(0.04, 0.05, 0.10).lerp(Color(0.70, 0.82, 0.95), day).lerp(Color(0.95, 0.55, 0.35), dusk * 0.6)
	env.fog_light_color = horizon
	env.ambient_light_color = Color(0.16, 0.18, 0.30).lerp(Color(0.5, 0.54, 0.62), day)
	sun.light_energy = lerpf(0.35, 1.2, day)
	sun.light_color = Color(0.55, 0.65, 1.0).lerp(Color(1.0, 0.95, 0.85), day)
	sun.rotation_degrees = Vector3(-clampf(20.0 + sn * 55.0, 28.0, 80.0), 90.0 + (hour - 12.0) * 7.0, 0.0)
	is_night = day < 0.35
	City.set_night(1.0 - day)

	sky_timer -= delta
	if sky_timer <= 0.0:
		sky_timer = 0.5
		sky_mat.sky_top_color = Color(0.01, 0.01, 0.04).lerp(Color(0.25, 0.48, 0.85), day)
		sky_mat.sky_horizon_color = horizon
		sky_mat.ground_horizon_color = horizon
		sky_mat.ground_bottom_color = Color(0.05, 0.07, 0.05).lerp(Color(0.25, 0.33, 0.22), day)

	# adaptive resolution: keep 60 fps by lowering 3D resolution (and shadows) when it dips
	perf_t -= delta
	if perf_t <= 0.0:
		perf_t = 1.0
		var f := Engine.get_frames_per_second()
		if f < 54:
			good_s = 0
			res_scale = maxf(0.6, res_scale - 0.07)
		elif f >= 59:
			good_s += 1
			if good_s >= 6 and res_scale < 1.0:
				res_scale = minf(1.0, res_scale + 0.05)
				good_s = 0
		get_viewport().scaling_3d_scale = res_scale
		sun.shadow_enabled = res_scale > 0.68
		env.glow_enabled = res_scale >= 0.85
