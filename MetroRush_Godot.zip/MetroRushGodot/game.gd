class_name Game
extends Node3D

static var inst: Game

var hero: Player
var players: Array[Player] = []
var cam: OrbitCam
var hud: Hud
var sun: DirectionalLight3D
var env: Environment
var marker: MeshInstance3D
var hour := 17.0
var is_night := false


func _ready() -> void:
	inst = self
	randomize()
	Engine.max_fps = 60
	DisplayServer.screen_set_keep_on(true)

	var we := WorldEnvironment.new()
	env = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.58, 0.78, 0.96)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.5, 0.54, 0.62)
	env.ambient_light_energy = 1.0
	env.fog_enabled = true
	env.fog_light_color = Color(0.58, 0.78, 0.96)
	env.fog_density = 0.003
	we.environment = env
	add_child(we)

	sun = DirectionalLight3D.new()
	sun.shadow_enabled = true
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
	sun.directional_shadow_max_distance = 80.0
	add_child(sun)

	City.build(self)

	cam = OrbitCam.new()
	cam.far = 600.0
	cam.fov = 62.0
	cam.cull_mask = (1 << 19) - 1   # layer 20 = minimap marker only
	add_child(cam)
	cam.current = true

	var colors := [
		Color(0.80, 0.12, 0.12), Color(0.12, 0.30, 0.75), Color(0.92, 0.92, 0.92),
		Color(0.95, 0.75, 0.10), Color(0.10, 0.10, 0.12), Color(0.95, 0.45, 0.10),
		Color(0.15, 0.55, 0.35)
	]

	# two protagonists, each with a personal car
	var c := City.node_pos(City.N / 2, City.N / 2)
	var gur := Player.create("Gurniwaz Singh", Color(0.12, 0.20, 0.55), Color(0.95, 0.5, 0.15), c + Vector3(0.5, 0.2, 20.0))
	var ari := Player.create("Aridaman Virk", Color(0.93, 0.55, 0.10), Color(0.2, 0.45, 0.85), c + Vector3(0.5, 0.2, -20.0))
	add_child(gur)
	add_child(ari)
	players.append(gur)
	players.append(ari)
	hero = gur
	gur.active = true
	cam.set_target(gur, 5.5)

	var v1 := Car.create(c + Vector3(3.5, 0.2, 22.0), 0.0, colors[0])
	v1.owned = true
	add_child(v1)
	var v2 := Car.create(c + Vector3(3.5, 0.2, -22.0), 0.0, colors[2])
	v2.owned = true
	add_child(v2)

	# other parked cars (drivable)
	for k in range(16):
		var pi: int = randi_range(0, City.N)
		var pj: int = randi_range(0, City.N - 1)
		var pos := Vector3(pi * City.PITCH + 5.2, 0.2, pj * City.PITCH + randf_range(14.0, 50.0))
		add_child(Car.create(pos, 0.0, colors[randi() % colors.size()]))

	# traffic
	for k in range(30):
		var w := Walker.new()
		w.speed = randf_range(8.0, 13.0)
		w.lateral = 3.5
		w.height = 0.05
		var cs := CollisionShape3D.new()
		var sh := BoxShape3D.new()
		sh.size = Vector3(1.9, 1.2, 4.2)
		cs.shape = sh
		cs.position = Vector3(0.0, 0.6, 0.0)
		w.add_child(cs)
		Car.build_body(w, colors[randi() % colors.size()], [], [])
		add_child(w)
		w.start_walk()

	# pedestrians
	for k in range(60):
		var w := Walker.new()
		w.speed = randf_range(1.2, 1.9)
		w.lateral = 9.0
		w.height = 0.0
		var mi := MeshInstance3D.new()
		var cm := CapsuleMesh.new()
		cm.radius = 0.25
		cm.height = 1.7
		cm.radial_segments = 8
		cm.rings = 3
		mi.mesh = cm
		mi.material_override = City.flat(Color.from_hsv(randf(), 0.5, 0.85))
		mi.position = Vector3(0.0, 0.85, 0.0)
		w.add_child(mi)
		add_child(w)
		w.start_walk()

	# minimap marker (only the minimap camera sees layer 20)
	marker = MeshInstance3D.new()
	var mm := BoxMesh.new()
	mm.size = Vector3(10.0, 1.0, 16.0)
	marker.mesh = mm
	marker.material_override = City.glow(Color(1.0, 0.25, 0.2))
	marker.layers = 1 << 19
	marker.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(marker)
	var nose := MeshInstance3D.new()
	var nm := BoxMesh.new()
	nm.size = Vector3(4.0, 1.2, 6.0)
	nose.mesh = nm
	nose.material_override = City.glow(Color(1.0, 0.9, 0.2))
	nose.layers = 1 << 19
	nose.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	nose.position = Vector3(0.0, 0.0, -9.0)
	marker.add_child(nose)

	var layer := CanvasLayer.new()
	add_child(layer)
	hud = Hud.new()
	layer.add_child(hud)


func switch_hero() -> void:
	var other: Player = players[1]
	if hero == players[1]:
		other = players[0]
	hero.force_exit()
	hero.active = false
	other.active = true
	hero = other
	cam.set_target(other, 5.5)


func _process(delta: float) -> void:
	if Inp.switch_pressed:
		Inp.switch_pressed = false
		switch_hero()

	hour = fposmod(hour + delta * (24.0 / 720.0), 24.0)
	var sn := sin((hour - 6.0) / 24.0 * TAU)
	var day := clampf((sn + 0.15) / 0.5, 0.0, 1.0)
	var dusk := clampf(1.0 - absf(sn) / 0.3, 0.0, 1.0)
	var sky := Color(0.03, 0.04, 0.09).lerp(Color(0.58, 0.78, 0.96), day).lerp(Color(0.95, 0.55, 0.35), dusk * 0.6)
	env.background_color = sky
	env.fog_light_color = sky
	env.ambient_light_color = Color(0.06, 0.07, 0.13).lerp(Color(0.5, 0.54, 0.62), day)
	sun.light_energy = maxf(0.0, sn) * 1.2
	sun.rotation_degrees = Vector3(-clampf(20.0 + sn * 55.0, 5.0, 80.0), 90.0 + (hour - 12.0) * 7.0, 0.0)
	is_night = day < 0.35

	var tp := hero.global_position
	marker.global_position = Vector3(tp.x, 200.0, tp.z)
	if hero.car != null:
		marker.rotation.y = hero.car.rotation.y
	else:
		marker.rotation.y = hero.rotation.y
	hud.update_minimap(tp)
