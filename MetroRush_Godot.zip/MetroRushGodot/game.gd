class_name Game
extends Node3D

static var inst: Game

var hero: Player
var players: Array[Player] = []
var cam: OrbitCam
var hud: Hud
var sun: DirectionalLight3D
var env: Environment
var sky_mat: ProceduralSkyMaterial
var sky_timer := 0.0
var hour := 17.0
var is_night := false


func _ready() -> void:
	inst = self
	randomize()
	Engine.max_fps = 60
	DisplayServer.screen_set_keep_on(true)

	var we := WorldEnvironment.new()
	env = Environment.new()
	sky_mat = ProceduralSkyMaterial.new()
	var sky := Sky.new()
	sky.sky_material = sky_mat
	sky.radiance_size = Sky.RADIANCE_SIZE_32
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.reflected_light_source = Environment.REFLECTION_SOURCE_DISABLED
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.5, 0.54, 0.62)
	env.ambient_light_energy = 1.0
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color(0.7, 0.82, 0.95)
	env.fog_density = 0.0025
	we.environment = env
	add_child(we)

	sun = DirectionalLight3D.new()
	sun.shadow_enabled = true
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
	sun.directional_shadow_max_distance = 70.0
	add_child(sun)

	City.build(self)

	cam = OrbitCam.new()
	cam.far = 600.0
	cam.fov = 62.0
	add_child(cam)
	cam.current = true

	var colors := [
		Color(0.80, 0.12, 0.12), Color(0.12, 0.30, 0.75), Color(0.92, 0.92, 0.92),
		Color(0.95, 0.75, 0.10), Color(0.10, 0.10, 0.12), Color(0.95, 0.45, 0.10),
		Color(0.15, 0.55, 0.35)
	]

	# two protagonists: Adams (male) and Eve (female), each with a personal car
	var c := City.node_pos(City.N / 2, City.N / 2)
	var adams := Player.create("Adams", false, c + Vector3(0.5, 0.2, 20.0))
	var eve := Player.create("Eve", true, c + Vector3(0.5, 0.2, -20.0))
	add_child(adams)
	add_child(eve)
	players.append(adams)
	players.append(eve)
	hero = adams
	adams.active = true
	cam.set_target(adams, 5.5)

	var v1 := Car.create(c + Vector3(3.5, 0.2, 22.0), 0.0, colors[0])
	v1.owned = true
	add_child(v1)
	var v2 := Car.create(c + Vector3(3.5, 0.2, -22.0), 0.0, colors[2])
	v2.owned = true
	add_child(v2)

	for k in range(16):
		var pi: int = randi_range(0, City.N)
		var pj: int = randi_range(0, City.N - 1)
		var pos := Vector3(pi * City.PITCH + 5.2, 0.2, pj * City.PITCH + randf_range(14.0, 50.0))
		add_child(Car.create(pos, 0.0, colors[randi() % colors.size()]))

	# traffic: one draw call per car
	for k in range(30):
		var w := Walker.new()
		w.speed = randf_range(8.0, 13.0)
		w.lateral = 3.5
		w.height = 0.05
		var cs := CollisionShape3D.new()
		var sh := BoxShape3D.new()
		sh.size = Vector3(1.9, 1.2, 4.2)
		cs.shape = sh
		cs.position = Vector3(0.0, 0.6, 0.0)
		w.add_child(cs)
		var col: Color = colors[randi() % colors.size()]
		Car.add_visual(w, col, false, [], [])
		w.add_to_group("traffic")
		add_child(w)
		w.start_walk()

	# pedestrians: one draw call each, with a walking bob
	for k in range(60):
		var w := Walker.new()
		w.is_ped = true
		w.speed = randf_range(1.2, 1.9)
		w.lateral = 9.0
		w.height = 0.0
		var vis := Node3D.new()
		w.add_child(vis)
		var mi := MeshInstance3D.new()
		mi.mesh = MeshKit.ped_mesh(Color.from_hsv(randf(), 0.55, 0.8), Color.from_hsv(randf(), 0.3, 0.3), Color(0.85, 0.66, 0.5), Color(0.2, 0.14, 0.1))
		mi.material_override = MeshKit.shared_vc()
		vis.add_child(mi)
		w.visual = vis
		add_child(w)
		w.start_walk()

	add_child(EngineSound.new())

	var layer := CanvasLayer.new()
	add_child(layer)
	hud = Hud.new()
	layer.add_child(hud)


func switch_hero() -> void:
	var other: Player = players[1]
	if hero == players[1]:
		other = players[0]
	hero.force_exit()
	hero.active = false
	other.active = true
	hero = other
	cam.set_target(other, 5.5)


func _process(delta: float) -> void:
	if Inp.switch_pressed:
		Inp.switch_pressed = false
		switch_hero()

	hour = fposmod(hour + delta * (24.0 / 720.0), 24.0)
	var sn := sin((hour - 6.0) / 24.0 * TAU)
	var day := clampf((sn + 0.15) / 0.5, 0.0, 1.0)
	var dusk := clampf(1.0 - absf(sn) / 0.3, 0.0, 1.0)
	var horizon := Color(0.04, 0.05, 0.10).lerp(Color(0.70, 0.82, 0.95), day).lerp(Color(0.95, 0.55, 0.35), dusk * 0.6)
	env.fog_light_color = horizon
	env.ambient_light_color = Color(0.07, 0.08, 0.14).lerp(Color(0.5, 0.54, 0.62), day)
	sun.light_energy = maxf(0.0, sn) * 1.2
	sun.rotation_degrees = Vector3(-clampf(20.0 + sn * 55.0, 5.0, 80.0), 90.0 + (hour - 12.0) * 7.0, 0.0)
	is_night = day < 0.35
	City.set_night(1.0 - day)

	sky_timer -= delta
	if sky_timer <= 0.0:
		sky_timer = 0.5
		sky_mat.sky_top_color = Color(0.01, 0.01, 0.04).lerp(Color(0.25, 0.48, 0.85), day)
		sky_mat.sky_horizon_color = horizon
		sky_mat.ground_horizon_color = horizon
		sky_mat.ground_bottom_color = Color(0.05, 0.07, 0.05).lerp(Color(0.25, 0.33, 0.22), day)
