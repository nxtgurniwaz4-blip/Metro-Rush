class_name Inp
extends RefCounted

static var move := Vector2.ZERO
static var look := Vector2.ZERO
static var brake := false
static var enter_pressed := false
static var switch_pressed := false
