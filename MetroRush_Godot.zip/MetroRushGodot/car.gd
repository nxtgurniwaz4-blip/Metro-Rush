class_name Car
extends CharacterBody3D
# Arcade car: kinematic body, bicycle-model steering. Front of the car is -Z.

const MAX_SPEED := 38.0
const WHEELBASE := 2.6

var driven := false
var owned := false
var health := 1.0
var speed := 0.0
var steer := 0.0
var base_color := Color.WHITE
var body_mat: StandardMaterial3D
var roll_nodes: Array = []
var steer_nodes: Array = []


static func build_body(root: Node3D, color: Color, rolls: Array, steers: Array) -> StandardMaterial3D:
	var bmat := StandardMaterial3D.new()
	bmat.albedo_color = color
	bmat.roughness = 0.5
	bmat.metallic = 0.3
	City.box(root, Vector3(0.0, 0.55, 0.0), Vector3(1.9, 0.6, 4.2), bmat, false)
	City.box(root, Vector3(0.0, 1.1, 0.3), Vector3(1.6, 0.5, 2.1), City.flat(Color(0.12, 0.16, 0.22)), false)
	var head := City.glow(Color(1.0, 0.95, 0.65))
	var tail := City.glow(Color(0.9, 0.1, 0.1))
	City.box(root, Vector3(-0.65, 0.65, -2.1), Vector3(0.35, 0.2, 0.06), head, false)
	City.box(root, Vector3(0.65, 0.65, -2.1), Vector3(0.35, 0.2, 0.06), head, false)
	City.box(root, Vector3(-0.65, 0.65, 2.1), Vector3(0.35, 0.2, 0.06), tail, false)
	City.box(root, Vector3(0.65, 0.65, 2.1), Vector3(0.35, 0.2, 0.06), tail, false)

	var tyre := City.flat(Color(0.05, 0.05, 0.05))
	var xs := [-0.9, 0.9, -0.9, 0.9]
	var zs := [-1.3, -1.3, 1.3, 1.3]
	for k in range(4):
		var pivot := Node3D.new()
		pivot.position = Vector3(xs[k], 0.38, zs[k])
		root.add_child(pivot)
		var roll := Node3D.new()
		pivot.add_child(roll)
		var mi := MeshInstance3D.new()
		var cm := CylinderMesh.new()
		cm.top_radius = 0.38
		cm.bottom_radius = 0.38
		cm.height = 0.26
		cm.radial_segments = 16
		cm.rings = 1
		mi.mesh = cm
		mi.material_override = tyre
		mi.rotation_degrees = Vector3(0.0, 0.0, 90.0)
		roll.add_child(mi)
		rolls.append(roll)
		if zs[k] < 0.0:
			steers.append(pivot)
	return bmat


static func create(pos: Vector3, yaw: float, color: Color) -> Car:
	var c := Car.new()
	c.position = pos
	c.rotation.y = yaw
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = Vector3(1.9, 1.2, 4.2)
	cs.shape = sh
	cs.position = Vector3(0.0, 0.6, 0.0)
	c.add_child(cs)
	c.base_color = color
	c.body_mat = Car.build_body(c, color, c.roll_nodes, c.steer_nodes)
	c.floor_snap_length = 0.3
	c.add_to_group("cars")
	return c


func _tint() -> void:
	body_mat.albedo_color = base_color.lerp(Color(0.12, 0.12, 0.12), (1.0 - health) * 0.6)


func _physics_process(delta: float) -> void:
	var throttle := 0.0
	var steer_in := 0.0
	var brake := true
	if driven:
		throttle = Inp.move.y
		steer_in = Inp.move.x
		brake = Inp.brake

	var top := MAX_SPEED * (0.4 + 0.6 * health)
	if brake:
		speed = move_toward(speed, 0.0, 28.0 * delta)
	elif absf(throttle) > 0.05:
		if throttle * speed < -0.5:
			speed = move_toward(speed, 0.0, 24.0 * delta)
		else:
			var lim := top if throttle > 0.0 else 10.0
			var room := clampf(1.0 - absf(speed) / lim, 0.0, 1.0)
			speed += throttle * 11.0 * room * delta
	else:
		speed = move_toward(speed, 0.0, 3.5 * delta)

	steer = move_toward(steer, steer_in, 5.0 * delta)
	var sa := steer * lerpf(0.55, 0.18, clampf(absf(speed) / MAX_SPEED, 0.0, 1.0))
	rotate_y(-(speed / WHEELBASE) * tan(sa) * delta)

	var fwd := -global_transform.basis.z
	velocity.x = fwd.x * speed
	velocity.z = fwd.z * speed
	if is_on_floor():
		velocity.y = -0.5
	else:
		velocity.y -= 25.0 * delta

	var before := absf(speed)
	move_and_slide()
	var fwd2 := -global_transform.basis.z
	speed = velocity.x * fwd2.x + velocity.z * fwd2.z
	var lost := before - absf(speed)
	if lost > 5.0:
		health = maxf(0.0, health - lost / 45.0)
		_tint()

	for r in roll_nodes:
		r.rotation.x -= speed * delta / 0.38
	for p in steer_nodes:
		p.rotation.y = -steer * 0.5
