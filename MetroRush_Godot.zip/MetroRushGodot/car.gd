class_name Car
extends CharacterBody3D
# Arcade car: kinematic body, bicycle-model steering. Front of the car is -Z.

const MAX_SPEED := 40.0
const WHEELBASE := 2.7

static var _beep: AudioStreamWAV

var driven := false
var owned := false
var stolen := false
var locked := false
var security := 0
var has_tracker := false
var is_police := false
var ai := false
var ai_in := Vector2.ZERO
var alarm_t := 0.0
var health := 1.0
var speed := 0.0
var steer := 0.0
var base_color := Color.WHITE
var body_mi: Node3D
var body_mat: StandardMaterial3D
var siren: MeshInstance3D
var alarm_audio: AudioStreamPlayer3D
var headlight: SpotLight3D
var roll_nodes: Array = []
var steer_nodes: Array = []
var last_good := Transform3D.IDENTITY


static func add_visual(root: Node3D, color: Color, wheels_separate: bool, rolls: Array, steers: Array) -> Node3D:
	var car_files := Assets.files("car")
	if car_files.size() > 0:
		var am := Assets.instance(car_files[randi() % car_files.size()], 4.3, false)
		if am != null:
			root.add_child(am)
			return am
	var mi := MeshInstance3D.new()
	mi.mesh = MeshKit.car_mesh(color, not wheels_separate)
	mi.material_override = MeshKit.shared_vc()
	root.add_child(mi)
	if wheels_separate:
		var xs := [-0.9, 0.9, -0.9, 0.9]
		var zs := [-1.3, -1.3, 1.3, 1.3]
		for k in range(4):
			var pivot := Node3D.new()
			pivot.position = Vector3(xs[k], 0.38, zs[k])
			root.add_child(pivot)
			var roll := Node3D.new()
			pivot.add_child(roll)
			var wmi := MeshInstance3D.new()
			wmi.mesh = MeshKit.wheel_mesh()
			wmi.material_override = MeshKit.shared_vc()
			roll.add_child(wmi)
			rolls.append(roll)
			if zs[k] < 0.0:
				steers.append(pivot)
	return mi


static func create(pos: Vector3, yaw: float, color: Color, sec: int = -1) -> Car:
	if sec < 0:
		var r := randf()
		if r < 0.25:
			sec = 0
		elif r < 0.65:
			sec = 1
		elif r < 0.90:
			sec = 2
		else:
			sec = 3
	var c := Car.new()
	c.position = pos
	c.rotation.y = yaw
	c.security = sec
	c.locked = sec > 0
	c.has_tracker = sec >= 3
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = Vector3(1.9, 1.2, 4.2)
	cs.shape = sh
	cs.position = Vector3(0.0, 0.6, 0.0)
	c.add_child(cs)
	c.base_color = color
	c.body_mi = Car.add_visual(c, color, true, c.roll_nodes, c.steer_nodes)
	if c.body_mi is MeshInstance3D:
		c.body_mat = MeshKit.vc_material()
		(c.body_mi as MeshInstance3D).material_override = c.body_mat
	c.floor_snap_length = 0.3
	var hl := SpotLight3D.new()
	hl.position = Vector3(0.0, 0.9, -2.0)
	hl.rotation_degrees.x = -4.0
	hl.spot_range = 45.0
	hl.spot_angle = 38.0
	hl.light_energy = 3.0
	hl.visible = false
	c.add_child(hl)
	c.headlight = hl
	c.add_to_group("cars")
	return c


static func create_police(pos: Vector3) -> Car:
	var c := Car.create(pos, 0.0, Color(0.08, 0.10, 0.22), 0)
	c.is_police = true
	c.locked = true
	c.remove_from_group("cars")
	c.add_to_group("police")
	var bar := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.9, 0.14, 0.35)
	bar.mesh = bm
	bar.material_override = City.glow(Color(0.2, 0.3, 1.0))
	bar.position = Vector3(0.0, 1.5, 0.2)
	c.add_child(bar)
	c.siren = bar
	return c


static func beep_stream() -> AudioStreamWAV:
	if _beep != null:
		return _beep
	var rate := 22050
	var n := rate / 2
	var bytes := PackedByteArray()
	bytes.resize(n * 2)
	for i in range(n):
		var v := 0.0
		if i < n / 2:
			v = sin(TAU * 880.0 * float(i) / float(rate)) * 0.35
		bytes.encode_s16(i * 2, int(v * 32767.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = false
	w.data = bytes
	w.loop_mode = AudioStreamWAV.LOOP_FORWARD
	w.loop_begin = 0
	w.loop_end = n
	_beep = w
	return w


func security_name() -> String:
	match security:
		0:
			return "no security"
		1:
			return "basic lock"
		2:
			return "lock + alarm"
	return "lock + alarm + tracker"


func start_alarm() -> void:
	if alarm_t > 0.0:
		return
	alarm_t = 20.0
	if alarm_audio == null:
		alarm_audio = AudioStreamPlayer3D.new()
		alarm_audio.stream = Car.beep_stream()
		alarm_audio.max_distance = 90.0
		alarm_audio.unit_size = 12.0
		add_child(alarm_audio)
	alarm_audio.play()
	Wanted.report(global_position, 0.4, true, Game.inst.hero, self)


func _tint() -> void:
	if body_mat == null:
		return
	body_mat.albedo_color = Color.WHITE.lerp(Color(0.35, 0.35, 0.35), (1.0 - health) * 0.7)


func _process(delta: float) -> void:
	if headlight != null:
		headlight.visible = (driven or is_police) and Game.inst.is_night
	if siren != null:
		if (Time.get_ticks_msec() / 200) % 2 == 0:
			siren.material_override = City.glow(Color(0.2, 0.3, 1.0))
		else:
			siren.material_override = City.glow(Color(1.0, 0.15, 0.1))
	if alarm_t > 0.0:
		alarm_t -= delta
		if driven:
			alarm_t = 0.0
		if alarm_t > 0.0:
			if body_mat != null:
				if (Time.get_ticks_msec() / 250) % 2 == 0:
					body_mat.albedo_color = Color(1.0, 0.7, 0.3)
				else:
					body_mat.albedo_color = Color.WHITE
		else:
			if alarm_audio != null:
				alarm_audio.stop()
			_tint()


func _physics_process(delta: float) -> void:
	# parked cars go to sleep once they have settled (saves CPU for 60 fps)
	if not driven and not ai and absf(speed) < 0.05 and is_on_floor():
		set_physics_process(false)
		return

	if not global_transform.origin.is_finite():
		global_transform = last_good
		speed = 0.0
		velocity = Vector3.ZERO
	else:
		last_good = global_transform

	var throttle := 0.0
	var steer_in := 0.0
	var brake := true
	if ai:
		throttle = ai_in.y
		steer_in = ai_in.x
		brake = false
	elif driven:
		throttle = Inp.move.y
		steer_in = Inp.move.x
		brake = Inp.brake

	var top := MAX_SPEED * (0.45 + 0.55 * health)
	if brake:
		speed = move_toward(speed, 0.0, 34.0 * delta)
	elif absf(throttle) > 0.05:
		if throttle * speed < -0.5:
			speed = move_toward(speed, 0.0, 30.0 * delta)
		else:
			var lim := 12.0
			if throttle > 0.0:
				lim = top
			var room := clampf(1.0 - absf(speed) / lim, 0.0, 1.0)
			speed += throttle * 16.0 * (0.25 + 0.75 * room) * delta
			speed = clampf(speed, -12.0, top)
	else:
		speed = move_toward(speed, 0.0, 3.5 * delta)

	steer = move_toward(steer, steer_in, 5.0 * delta)
	var sa := steer * lerpf(0.62, 0.16, clampf(absf(speed) / MAX_SPEED, 0.0, 1.0))
	rotate_y(-(speed / WHEELBASE) * tan(sa) * delta)

	var fwd := -global_transform.basis.z
	velocity.x = fwd.x * speed
	velocity.z = fwd.z * speed
	if is_on_floor():
		velocity.y = -0.5
	else:
		velocity.y -= 25.0 * delta

	var before := absf(speed)
	move_and_slide()
	var fwd2 := -global_transform.basis.z
	speed = velocity.x * fwd2.x + velocity.z * fwd2.z
	var lost := before - absf(speed)
	if lost > 5.0:
		health = maxf(0.0, health - lost / 45.0)
		if alarm_t <= 0.0:
			_tint()

	body_mi.rotation.z = lerpf(body_mi.rotation.z, -steer * clampf(absf(speed) / MAX_SPEED, 0.0, 1.0) * 0.05, 8.0 * delta)
	for r in roll_nodes:
		r.rotation.x -= speed * delta / 0.38
	for p in steer_nodes:
		p.rotation.y = -steer * 0.5
