class_name Car
extends CharacterBody3D
# Arcade car: kinematic body, bicycle-model steering. Front of the car is -Z.

const MAX_SPEED := 40.0
const WHEELBASE := 2.7

var driven := false
var owned := false
var health := 1.0
var speed := 0.0
var steer := 0.0
var base_color := Color.WHITE
var body_mi: MeshInstance3D
var body_mat: StandardMaterial3D
var roll_nodes: Array = []
var steer_nodes: Array = []
var last_good := Transform3D.IDENTITY


static func add_visual(root: Node3D, color: Color, wheels_separate: bool, rolls: Array, steers: Array) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = MeshKit.car_mesh(color, not wheels_separate)
	mi.material_override = MeshKit.shared_vc()
	root.add_child(mi)
	if wheels_separate:
		var xs := [-0.9, 0.9, -0.9, 0.9]
		var zs := [-1.3, -1.3, 1.3, 1.3]
		for k in range(4):
			var pivot := Node3D.new()
			pivot.position = Vector3(xs[k], 0.38, zs[k])
			root.add_child(pivot)
			var roll := Node3D.new()
			pivot.add_child(roll)
			var wmi := MeshInstance3D.new()
			wmi.mesh = MeshKit.wheel_mesh()
			wmi.material_override = MeshKit.shared_vc()
			roll.add_child(wmi)
			rolls.append(roll)
			if zs[k] < 0.0:
				steers.append(pivot)
	return mi


static func create(pos: Vector3, yaw: float, color: Color) -> Car:
	var c := Car.new()
	c.position = pos
	c.rotation.y = yaw
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = Vector3(1.9, 1.2, 4.2)
	cs.shape = sh
	cs.position = Vector3(0.0, 0.6, 0.0)
	c.add_child(cs)
	c.base_color = color
	c.body_mi = Car.add_visual(c, color, true, c.roll_nodes, c.steer_nodes)
	c.body_mat = MeshKit.vc_material()
	c.body_mi.material_override = c.body_mat
	c.floor_snap_length = 0.3
	c.add_to_group("cars")
	return c


func _tint() -> void:
	body_mat.albedo_color = Color.WHITE.lerp(Color(0.35, 0.35, 0.35), (1.0 - health) * 0.7)


func _physics_process(delta: float) -> void:
	if not global_transform.origin.is_finite():
		global_transform = last_good
		speed = 0.0
		velocity = Vector3.ZERO
	else:
		last_good = global_transform

	var throttle := 0.0
	var steer_in := 0.0
	var brake := true
	if driven:
		throttle = Inp.move.y
		steer_in = Inp.move.x
		brake = Inp.brake

	var top := MAX_SPEED * (0.45 + 0.55 * health)
	if brake:
		speed = move_toward(speed, 0.0, 34.0 * delta)
	elif absf(throttle) > 0.05:
		if throttle * speed < -0.5:
			speed = move_toward(speed, 0.0, 30.0 * delta)
		else:
			var lim := 12.0
			if throttle > 0.0:
				lim = top
			var room := clampf(1.0 - absf(speed) / lim, 0.0, 1.0)
			speed += throttle * 16.0 * (0.25 + 0.75 * room) * delta
			speed = clampf(speed, -12.0, top)
	else:
		speed = move_toward(speed, 0.0, 3.5 * delta)

	steer = move_toward(steer, steer_in, 5.0 * delta)
	var sa := steer * lerpf(0.62, 0.16, clampf(absf(speed) / MAX_SPEED, 0.0, 1.0))
	rotate_y(-(speed / WHEELBASE) * tan(sa) * delta)

	var fwd := -global_transform.basis.z
	velocity.x = fwd.x * speed
	velocity.z = fwd.z * speed
	if is_on_floor():
		velocity.y = -0.5
	else:
		velocity.y -= 25.0 * delta

	var before := absf(speed)
	move_and_slide()
	var fwd2 := -global_transform.basis.z
	speed = velocity.x * fwd2.x + velocity.z * fwd2.z
	var lost := before - absf(speed)
	if lost > 5.0:
		health = maxf(0.0, health - lost / 45.0)
		_tint()

	body_mi.rotation.z = lerpf(body_mi.rotation.z, -steer * clampf(absf(speed) / MAX_SPEED, 0.0, 1.0) * 0.05, 8.0 * delta)
	for r in roll_nodes:
		r.rotation.x -= speed * delta / 0.38
	for p in steer_nodes:
		p.rotation.y = -steer * 0.5
