class_name Hud
extends Control
# Touch controls + HUD + minimap, all in code.

var move_id := -1
var look_id := -1
var brake_id := -1
var move_start := Vector2.ZERO
var move_cur := Vector2.ZERO
var s := 1.0
var act_c := Vector2.ZERO
var brk_c := Vector2.ZERO
var sw_c := Vector2.ZERO
var sv: SubViewport
var mini_cam: Camera3D
var mini_tex: TextureRect
var frame := 0


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

	sv = SubViewport.new()
	sv.size = Vector2i(320, 320)
	sv.render_target_update_mode = SubViewport.UPDATE_DISABLED
	add_child(sv)

	mini_cam = Camera3D.new()
	mini_cam.projection = Camera3D.PROJECTION_ORTHOGONAL
	mini_cam.size = 230.0
	mini_cam.near = 1.0
	mini_cam.far = 500.0
	var e := Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = Color(0.10, 0.12, 0.14)
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(0.9, 0.9, 0.9)
	e.ambient_light_energy = 0.9
	mini_cam.environment = e
	sv.add_child(mini_cam)
	mini_cam.rotation_degrees = Vector3(-90.0, 0.0, 0.0)
	mini_cam.current = true

	mini_tex = TextureRect.new()
	mini_tex.texture = sv.get_texture()
	mini_tex.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	mini_tex.stretch_mode = TextureRect.STRETCH_SCALE
	mini_tex.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(mini_tex)


func update_minimap(p: Vector3) -> void:
	mini_cam.global_position = p + Vector3(0.0, 250.0, 0.0)
	frame += 1
	if frame % 3 == 0:
		sv.render_target_update_mode = SubViewport.UPDATE_ONCE


func _in_circle(p: Vector2, c: Vector2, r: float) -> bool:
	return p.distance_to(c) <= r


func _input(event: InputEvent) -> void:
	if event is InputEventKey:
		var k := event as InputEventKey
		if k.pressed and not k.echo:
			if k.keycode == KEY_F:
				Inp.enter_pressed = true
			elif k.keycode == KEY_TAB:
				Inp.switch_pressed = true
		return

	if event is InputEventScreenTouch:
		var t := event as InputEventScreenTouch
		var p := t.position
		if t.pressed:
			if _in_circle(p, act_c, 80.0 * s):
				Inp.enter_pressed = true
			elif _in_circle(p, sw_c, 60.0 * s):
				Inp.switch_pressed = true
			elif _in_circle(p, brk_c, 80.0 * s):
				brake_id = t.index
				Inp.brake = true
			elif p.x < size.x * 0.45:
				if move_id < 0:
					move_id = t.index
					move_start = p
					move_cur = p
			elif look_id < 0:
				look_id = t.index
		else:
			if t.index == move_id:
				move_id = -1
				Inp.move = Vector2.ZERO
			elif t.index == look_id:
				look_id = -1
			elif t.index == brake_id:
				brake_id = -1
				Inp.brake = false
	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		if d.index == move_id:
			move_cur = d.position
			var v := (move_cur - move_start) / (110.0 * s)
			Inp.move = Vector2(v.x, -v.y).limit_length(1.0)
		elif d.index == look_id:
			Inp.look += d.relative / s


func _process(_d: float) -> void:
	s = size.y / 720.0
	act_c = Vector2(size.x - 260.0 * s, size.y - 120.0 * s)
	brk_c = Vector2(size.x - 100.0 * s, size.y - 120.0 * s)
	sw_c = Vector2(size.x - 260.0 * s, size.y - 270.0 * s)
	mini_tex.position = Vector2(20.0, 20.0) * s
	mini_tex.size = Vector2(260.0, 260.0) * s

	# keyboard fallback (desktop testing)
	if move_id < 0:
		var kx := int(Input.is_key_pressed(KEY_D)) - int(Input.is_key_pressed(KEY_A))
		var ky := int(Input.is_key_pressed(KEY_W)) - int(Input.is_key_pressed(KEY_S))
		Inp.move = Vector2(kx, ky)
	if brake_id < 0:
		Inp.brake = Input.is_key_pressed(KEY_SPACE)
	queue_redraw()


func _button(c: Vector2, r: float, text: String, held: bool) -> void:
	draw_circle(c, r, Color(1, 1, 1, 0.5 if held else 0.28))
	var font := ThemeDB.fallback_font
	draw_string(font, c + Vector2(-r, 8.0 * s), text, HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, int(24.0 * s), Color.WHITE)


func _draw() -> void:
	var hero: Player = Game.inst.hero
	var font := ThemeDB.fallback_font
	draw_rect(Rect2(Vector2(14.0, 14.0) * s, Vector2(272.0, 272.0) * s), Color(0, 0, 0, 0.6))

	if move_id >= 0:
		draw_circle(move_start, 110.0 * s, Color(1, 1, 1, 0.18))
		var off := (move_cur - move_start).limit_length(110.0 * s)
		draw_circle(move_start + off, 40.0 * s, Color(1, 1, 1, 0.5))

	var in_car := hero.car != null
	_button(act_c, 70.0 * s, "EXIT" if in_car else "ENTER", false)
	_button(brk_c, 70.0 * s, "BRAKE", brake_id >= 0)
	_button(sw_c, 50.0 * s, "SWITCH", false)

	var hh := int(Game.inst.hour)
	var mm := int((Game.inst.hour - float(hh)) * 60.0)
	var clock := "%02d:%02d" % [hh, mm]
	draw_string(font, Vector2(size.x - 560.0 * s, 44.0 * s), hero.char_name, HORIZONTAL_ALIGNMENT_RIGHT, 540.0 * s, int(30.0 * s), Color.WHITE)
	draw_string(font, Vector2(size.x - 560.0 * s, 80.0 * s), clock, HORIZONTAL_ALIGNMENT_RIGHT, 540.0 * s, int(26.0 * s), Color.WHITE)

	if in_car:
		var kmh := int(absf(hero.car.speed) * 3.6)
		draw_string(font, Vector2(size.x / 2.0 - 200.0 * s, size.y - 60.0 * s), "%d km/h" % kmh, HORIZONTAL_ALIGNMENT_CENTER, 400.0 * s, int(48.0 * s), Color.WHITE)
	elif Time.get_ticks_msec() < 25000:
		draw_string(font, Vector2(size.x / 2.0 - 400.0 * s, size.y - 60.0 * s), "Walk to a car and tap ENTER", HORIZONTAL_ALIGNMENT_CENTER, 800.0 * s, int(28.0 * s), Color.WHITE)
