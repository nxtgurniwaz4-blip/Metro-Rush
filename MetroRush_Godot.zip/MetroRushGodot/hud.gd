class_name Hud
extends Control
# Touch controls + HUD, all in code.

var move_id := -1
var look_id := -1
var brake_id := -1
var move_start := Vector2.ZERO
var move_cur := Vector2.ZERO
var s := 1.0
var act_c := Vector2.ZERO
var brk_c := Vector2.ZERO
var sw_c := Vector2.ZERO
var mini: MiniMap
var mouse_look := false
var mouse_brake := false


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	mini = MiniMap.new()
	add_child(mini)


func _in_circle(p: Vector2, c: Vector2, r: float) -> bool:
	return p.distance_to(c) <= r


func _input(event: InputEvent) -> void:
	if event is InputEventKey:
		var k := event as InputEventKey
		if k.pressed and not k.echo:
			if k.keycode == KEY_F or k.keycode == KEY_ENTER or k.keycode == KEY_KP_ENTER:
				Inp.enter_pressed = true
			elif k.keycode == KEY_TAB:
				Inp.switch_pressed = true
		return

	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_UP:
			Game.inst.cam.dist = clampf(Game.inst.cam.dist - 1.0, 3.0, 22.0)
		elif mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			Game.inst.cam.dist = clampf(Game.inst.cam.dist + 1.0, 3.0, 22.0)
		elif mb.button_index == MOUSE_BUTTON_LEFT or mb.button_index == MOUSE_BUTTON_RIGHT:
			if mb.pressed:
				var p := mb.position
				if mb.button_index == MOUSE_BUTTON_LEFT and _in_circle(p, act_c, 80.0 * s):
					Inp.enter_pressed = true
				elif mb.button_index == MOUSE_BUTTON_LEFT and _in_circle(p, sw_c, 60.0 * s):
					Inp.switch_pressed = true
				elif mb.button_index == MOUSE_BUTTON_LEFT and _in_circle(p, brk_c, 80.0 * s):
					mouse_brake = true
				else:
					mouse_look = true
			else:
				mouse_look = false
				mouse_brake = false
		return

	if event is InputEventMouseMotion:
		if mouse_look:
			Inp.look += (event as InputEventMouseMotion).relative * 0.7
		return

	if event is InputEventScreenTouch:
		var t := event as InputEventScreenTouch
		var p := t.position
		if t.pressed:
			if _in_circle(p, act_c, 80.0 * s):
				Inp.enter_pressed = true
			elif _in_circle(p, sw_c, 60.0 * s):
				Inp.switch_pressed = true
			elif _in_circle(p, brk_c, 80.0 * s):
				brake_id = t.index
			elif p.x < size.x * 0.45:
				if move_id < 0:
					move_id = t.index
					move_start = p
					move_cur = p
			elif look_id < 0:
				look_id = t.index
		else:
			if t.index == move_id:
				move_id = -1
				Inp.move = Vector2.ZERO
			elif t.index == look_id:
				look_id = -1
			elif t.index == brake_id:
				brake_id = -1
	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		if d.index == move_id:
			move_cur = d.position
			var v := (move_cur - move_start) / (110.0 * maxf(s, 0.1))
			Inp.move = Vector2(v.x, -v.y).limit_length(1.0)
		elif d.index == look_id:
			Inp.look += d.relative / maxf(s, 0.1)


func _process(_d: float) -> void:
	s = maxf(size.y / 720.0, 0.1)
	act_c = Vector2(size.x - 260.0 * s, size.y - 120.0 * s)
	brk_c = Vector2(size.x - 100.0 * s, size.y - 120.0 * s)
	sw_c = Vector2(size.x - 260.0 * s, size.y - 270.0 * s)
	mini.position = Vector2(20.0, 20.0) * s
	mini.size = Vector2(260.0, 260.0) * s

	if move_id < 0:
		var kx := float(Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT)) - float(Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT))
		var ky := float(Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP)) - float(Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN))
		var kv := Vector2(kx, ky)
		if kv.length() > 0.0:
			var on_foot := Game.inst.hero != null and Game.inst.hero.car == null
			if on_foot and not Input.is_key_pressed(KEY_SHIFT):
				kv = kv.normalized() * 0.6
			else:
				kv = kv.limit_length(1.0)
		Inp.move = kv
	Inp.brake = brake_id >= 0 or mouse_brake or Input.is_key_pressed(KEY_SPACE)
	var qe := float(Input.is_key_pressed(KEY_E)) - float(Input.is_key_pressed(KEY_Q))
	if qe != 0.0:
		Inp.look += Vector2(qe * 6.0, 0.0)
	queue_redraw()


func _button(c: Vector2, r: float, text: String, held: bool) -> void:
	draw_circle(c, r, Color(1, 1, 1, 0.5 if held else 0.28))
	var font := ThemeDB.fallback_font
	draw_string(font, c + Vector2(-r, 8.0 * s), text, HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, int(24.0 * s), Color.WHITE)


func _draw() -> void:
	var g := Game.inst
	if g == null or g.hero == null:
		return
	var hero: Player = g.hero
	var font := ThemeDB.fallback_font
	draw_rect(Rect2(Vector2(14.0, 14.0) * s, Vector2(272.0, 272.0) * s), Color(0, 0, 0, 0.6))

	if move_id >= 0:
		draw_circle(move_start, 110.0 * s, Color(1, 1, 1, 0.18))
		var off := (move_cur - move_start).limit_length(110.0 * s)
		draw_circle(move_start + off, 40.0 * s, Color(1, 1, 1, 0.5))

	var in_car := hero.car != null
	_button(act_c, 70.0 * s, "EXIT" if in_car else "ENTER", false)
	_button(brk_c, 70.0 * s, "BRAKE", brake_id >= 0)
	_button(sw_c, 50.0 * s, "SWITCH", false)

	var hh := int(g.hour)
	var mm := int((g.hour - float(hh)) * 60.0)
	var clock := "%02d:%02d" % [hh, mm]
	draw_string(font, Vector2(size.x - 560.0 * s, 44.0 * s), hero.char_name, HORIZONTAL_ALIGNMENT_RIGHT, 540.0 * s, int(30.0 * s), Color.WHITE)
	draw_string(font, Vector2(size.x - 560.0 * s, 80.0 * s), clock, HORIZONTAL_ALIGNMENT_RIGHT, 540.0 * s, int(26.0 * s), Color.WHITE)

	if in_car:
		var kmh := int(absf(hero.car.speed) * 3.6)
		draw_string(font, Vector2(size.x / 2.0 - 200.0 * s, size.y - 60.0 * s), "%d km/h" % kmh, HORIZONTAL_ALIGNMENT_CENTER, 400.0 * s, int(48.0 * s), Color.WHITE)
	elif Time.get_ticks_msec() < 25000:
		draw_string(font, Vector2(size.x / 2.0 - 400.0 * s, size.y - 60.0 * s), "Walk to a car and tap ENTER", HORIZONTAL_ALIGNMENT_CENTER, 800.0 * s, int(28.0 * s), Color.WHITE)

	draw_string(font, Vector2(20.0 * s, size.y - 36.0 * s), "WASD/arrows move  Shift run  Space brake  F/Enter enter-exit  Tab switch  Q/E or mouse-drag look  wheel zoom", HORIZONTAL_ALIGNMENT_LEFT, 1400.0 * s, int(15.0 * s), Color(1, 1, 1, 0.45))
	var info := "FPS %d   cam %s   you %s" % [Engine.get_frames_per_second(), str(g.cam.global_position.snapped(Vector3.ONE)), str(hero.global_position.snapped(Vector3.ONE))]
	draw_string(font, Vector2(20.0 * s, size.y - 14.0 * s), info, HORIZONTAL_ALIGNMENT_LEFT, 900.0 * s, int(16.0 * s), Color(1, 1, 1, 0.6))
