class_name Hud
extends Control
# Touch controls + HUD, all in code.

var move_id := -1
var look_id := -1
var brake_id := -1
var move_start := Vector2.ZERO
var move_cur := Vector2.ZERO
var s := 1.0
var act_c := Vector2.ZERO
var brk_c := Vector2.ZERO
var sw_c := Vector2.ZERO
var mini: MiniMap
var mouse_look := false
var zin_c := Vector2.ZERO
var zout_c := Vector2.ZERO
var mouse_brake := false


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	mini = MiniMap.new()
	add_child(mini)


func _in_circle(p: Vector2, c: Vector2, r: float) -> bool:
	return p.distance_to(c) <= r


func _input(event: InputEvent) -> void:
	if event is InputEventKey:
		var k := event as InputEventKey
		if k.pressed and not k.echo:
			if k.keycode == KEY_F or k.keycode == KEY_ENTER or k.keycode == KEY_KP_ENTER:
				Inp.enter_pressed = true
			elif k.keycode == KEY_TAB:
				Inp.switch_pressed = true
		return

	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_UP:
			Game.inst.cam.dist = clampf(Game.inst.cam.dist - 1.0, 3.0, 22.0)
		elif mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			Game.inst.cam.dist = clampf(Game.inst.cam.dist + 1.0, 3.0, 22.0)
		elif mb.button_index == MOUSE_BUTTON_LEFT or mb.button_index == MOUSE_BUTTON_RIGHT:
			if mb.pressed:
				var p := mb.position
				if mb.button_index == MOUSE_BUTTON_LEFT and _in_circle(p, zin_c, 40.0 * s):
					Game.inst.cam.dist = clampf(Game.inst.cam.dist - 1.5, 3.0, 22.0)
				elif mb.button_index == MOUSE_BUTTON_LEFT and _in_circle(p, zout_c, 40.0 * s):
					Game.inst.cam.dist = clampf(Game.inst.cam.dist + 1.5, 3.0, 22.0)
				elif mb.button_index == MOUSE_BUTTON_LEFT and _in_circle(p, act_c, 80.0 * s):
					Inp.enter_pressed = true
				elif mb.button_index == MOUSE_BUTTON_LEFT and _in_circle(p, sw_c, 60.0 * s):
					Inp.switch_pressed = true
				elif mb.button_index == MOUSE_BUTTON_LEFT and _in_circle(p, brk_c, 80.0 * s):
					mouse_brake = true
				else:
					mouse_look = true
			else:
				mouse_look = false
				mouse_brake = false
		return

	if event is InputEventMouseMotion:
		if mouse_look:
			Inp.look += (event as InputEventMouseMotion).relative * 0.7
		return

	if event is InputEventScreenTouch:
		var t := event as InputEventScreenTouch
		var p := t.position
		if t.pressed:
			if _in_circle(p, zin_c, 40.0 * s):
				Game.inst.cam.dist = clampf(Game.inst.cam.dist - 1.5, 3.0, 22.0)
			elif _in_circle(p, zout_c, 40.0 * s):
				Game.inst.cam.dist = clampf(Game.inst.cam.dist + 1.5, 3.0, 22.0)
			elif _in_circle(p, act_c, 80.0 * s):
				Inp.enter_pressed = true
			elif _in_circle(p, sw_c, 60.0 * s):
				Inp.switch_pressed = true
			elif _in_circle(p, brk_c, 80.0 * s):
				brake_id = t.index
			elif p.x < size.x * 0.45:
				if move_id < 0:
					move_id = t.index
					move_start = p
					move_cur = p
			elif look_id < 0:
				look_id = t.index
		else:
			if t.index == move_id:
				move_id = -1
				Inp.move = Vector2.ZERO
			elif t.index == look_id:
				look_id = -1
			elif t.index == brake_id:
				brake_id = -1
	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		if d.index == move_id:
			move_cur = d.position
			var v := (move_cur - move_start) / (110.0 * maxf(s, 0.1))
			Inp.move = Vector2(v.x, -v.y).limit_length(1.0)
		elif d.index == look_id:
			Inp.look += d.relative / maxf(s, 0.1)


func _process(_d: float) -> void:
	position = Vector2.ZERO
	size = get_viewport_rect().size
	s = maxf(size.y / 720.0, 0.1)
	zin_c = Vector2(size.x - 60.0 * s, size.y * 0.5 - 60.0 * s)
	zout_c = Vector2(size.x - 60.0 * s, size.y * 0.5 + 60.0 * s)
	act_c = Vector2(size.x - 260.0 * s, size.y - 120.0 * s)
	brk_c = Vector2(size.x - 100.0 * s, size.y - 120.0 * s)
	sw_c = Vector2(size.x - 260.0 * s, size.y - 270.0 * s)
	mini.position = Vector2(20.0, 20.0) * s
	mini.size = Vector2(260.0, 260.0) * s

	if move_id < 0:
		var kx := float(Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT)) - float(Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT))
		var ky := float(Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP)) - float(Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN))
		var kv := Vector2(kx, ky)
		if kv.length() > 0.0:
			var on_foot := Game.inst.hero != null and Game.inst.hero.car == null
			if on_foot and not Input.is_key_pressed(KEY_SHIFT):
				kv = kv.normalized() * 0.6
			else:
				kv = kv.limit_length(1.0)
		Inp.move = kv
	Inp.brake = brake_id >= 0 or mouse_brake or Input.is_key_pressed(KEY_SPACE)
	var qe := float(Input.is_key_pressed(KEY_E)) - float(Input.is_key_pressed(KEY_Q))
	if qe != 0.0:
		Inp.look += Vector2(qe * 6.0, 0.0)
	queue_redraw()


func _near_locked(hero: Player) -> Car:
	for n in get_tree().get_nodes_in_group("cars"):
		var c := n as Car
		if c != null and c.locked and c.global_position.distance_to(hero.global_position) < 5.0:
			return c
	return null


func _button(c: Vector2, r: float, text: String, held: bool) -> void:
	draw_circle(c, r, Color(1, 1, 1, 0.5 if held else 0.28))
	var font := ThemeDB.fallback_font
	draw_string(font, c + Vector2(-r, 8.0 * s), text, HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, int(24.0 * s), Color.WHITE)


func _draw() -> void:
	var g := Game.inst
	if g == null or g.hero == null:
		return
	var hero: Player = g.hero
	var font := ThemeDB.fallback_font
	draw_rect(Rect2(Vector2(14.0, 14.0) * s, Vector2(272.0, 272.0) * s), Color(0, 0, 0, 0.6))

	if move_id < 0:
		draw_circle(Vector2(190.0 * s, size.y - 190.0 * s), 110.0 * s, Color(1, 1, 1, 0.10))
		draw_circle(Vector2(190.0 * s, size.y - 190.0 * s), 40.0 * s, Color(1, 1, 1, 0.14))
	if move_id >= 0:
		draw_circle(move_start, 110.0 * s, Color(1, 1, 1, 0.18))
		var off := (move_cur - move_start).limit_length(110.0 * s)
		draw_circle(move_start + off, 40.0 * s, Color(1, 1, 1, 0.5))

	var in_car := hero.car != null
	var act_label := "ENTER"
	if hero.pick.active:
		act_label = "PICK"
	elif in_car:
		act_label = "EXIT"
	_button(act_c, 70.0 * s, act_label, false)
	var brk_label := "BRAKE"
	if hero.pick.active:
		brk_label = "SMASH"
	_button(brk_c, 70.0 * s, brk_label, brake_id >= 0 or mouse_brake)
	_button(sw_c, 50.0 * s, "SWITCH", false)
	_button(zin_c, 40.0 * s, "+", false)
	_button(zout_c, 40.0 * s, "-", false)

	var wt: Wanted = g.wanted
	if wt != null:
		var sz := 38.0 * s
		var gap := 10.0 * s
		var x0 := size.x / 2.0 - (6.0 * sz + 5.0 * gap) / 2.0
		var alpha := 1.0
		if wt.stars > 0 and not wt.recognized:
			alpha = 0.4 + 0.6 * absf(sin(Time.get_ticks_msec() / 160.0))
		for i in range(6):
			var sc := Color(1, 1, 1, 0.18)
			if i < wt.stars:
				sc = Color(1.0, 0.85, 0.1, alpha)
			draw_rect(Rect2(x0 + i * (sz + gap), 24.0 * s, sz, sz), sc)
		if wt.msg_t > 0.0:
			draw_string(font, Vector2(size.x / 2.0 - 450.0 * s, 100.0 * s), wt.message, HORIZONTAL_ALIGNMENT_CENTER, 900.0 * s, int(28.0 * s), Color.WHITE)
	if hero.pick.active:
		var lp := hero.pick
		var bw := 700.0 * s
		var bx := size.x / 2.0 - bw / 2.0
		var by := size.y / 2.0 - 30.0 * s
		draw_rect(Rect2(bx - 6.0 * s, by - 6.0 * s, bw + 12.0 * s, 72.0 * s), Color(0, 0, 0, 0.8))
		draw_rect(Rect2(bx, by, bw, 60.0 * s), Color(0.25, 0.25, 0.3))
		draw_rect(Rect2(bx + (lp.zone_c - lp.zone_h) * bw, by, lp.zone_h * 2.0 * bw, 60.0 * s), Color(0.2, 0.85, 0.35))
		draw_rect(Rect2(bx + lp.pos * bw - 5.0 * s, by - 10.0 * s, 10.0 * s, 80.0 * s), Color.WHITE)
		draw_string(font, Vector2(bx, by - 22.0 * s), "Pin %d / %d     Slips %d / 6" % [lp.pin + 1, lp.pins, lp.fails], HORIZONTAL_ALIGNMENT_CENTER, bw, int(26.0 * s), Color.WHITE)
		draw_string(font, Vector2(bx, by + 110.0 * s), "Tap PICK in the green zone  |  BRAKE = smash window (loud)", HORIZONTAL_ALIGNMENT_CENTER, bw, int(22.0 * s), Color.WHITE)

	var hh := int(g.hour)
	var mm := int((g.hour - float(hh)) * 60.0)
	var clock := "%02d:%02d" % [hh, mm]
	draw_string(font, Vector2(size.x - 560.0 * s, 44.0 * s), hero.char_name, HORIZONTAL_ALIGNMENT_RIGHT, 540.0 * s, int(30.0 * s), Color.WHITE)
	draw_string(font, Vector2(size.x - 560.0 * s, 80.0 * s), clock, HORIZONTAL_ALIGNMENT_RIGHT, 540.0 * s, int(26.0 * s), Color.WHITE)

	if in_car:
		var kmh := int(absf(hero.car.speed) * 3.6)
		draw_string(font, Vector2(size.x / 2.0 - 200.0 * s, size.y - 60.0 * s), "%d km/h" % kmh, HORIZONTAL_ALIGNMENT_CENTER, 400.0 * s, int(48.0 * s), Color.WHITE)
	elif hero.pick.active:
		pass
	elif _near_locked(hero) != null:
		var lc := _near_locked(hero)
		draw_string(font, Vector2(size.x / 2.0 - 400.0 * s, size.y - 60.0 * s), "Locked (%s) - ENTER to pick the lock" % lc.security_name(), HORIZONTAL_ALIGNMENT_CENTER, 800.0 * s, int(28.0 * s), Color.WHITE)
	elif Time.get_ticks_msec() < 25000:
		draw_string(font, Vector2(size.x / 2.0 - 400.0 * s, size.y - 60.0 * s), "Walk to a car and tap ENTER", HORIZONTAL_ALIGNMENT_CENTER, 800.0 * s, int(28.0 * s), Color.WHITE)

	draw_string(font, Vector2(20.0 * s, size.y - 36.0 * s), "WASD/arrows move  Shift run  Space brake  F/Enter enter-exit  Tab switch  Q/E or mouse-drag look  wheel zoom", HORIZONTAL_ALIGNMENT_LEFT, 1400.0 * s, int(15.0 * s), Color(1, 1, 1, 0.45))
	var info := "FPS %d   cam %s   you %s" % [Engine.get_frames_per_second(), str(g.cam.global_position.snapped(Vector3.ONE)), str(hero.global_position.snapped(Vector3.ONE))]
	draw_string(font, Vector2(20.0 * s, size.y - 14.0 * s), info, HORIZONTAL_ALIGNMENT_LEFT, 900.0 * s, int(16.0 * s), Color(1, 1, 1, 0.6))
