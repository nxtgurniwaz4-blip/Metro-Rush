# Metro Rush (Godot 4.3): original 3D open-world driving game for iPad

Free toolchain: Godot + Codemagic free tier. No Unity, no Apple developer account, no Mac.
Bundle id: com.Gurniwaz.metrorush. iPad only, landscape, Mobile renderer (Metal).

## In this build (v2)
- Protagonists: Adams (male) and Eve (female); SWITCH between them; walk animation
- City built from MultiMeshes (few draw calls): textured towers with lit windows at night, road markings,
  crosswalks, street lamps, parks, sky, fog, day/night cycle, sun shadows
- Better cars (hood, cabin, bumpers, lights, mirrors, rolling/steering wheels, body lean, damage tint, speed FOV)
- Procedural engine sound, 18 drivable cars, 30 traffic cars, 60 walking pedestrians
- Minimap drawn from the grid, speed readout, multi-touch controls, on-screen FPS/camera debug line
- Keyboard + mouse: WASD/arrows move, Shift run, Space brake, F/Enter enter-exit, Tab switch, Q/E or mouse-drag look, wheel zoom

## v3 additions
- Car security levels (none / lock / lock+alarm / lock+alarm+tracker), lock-picking minigame, smash window, alarms
- Carjack traffic cars (ENTER next to one)
- Six-star wanted level: witnesses, police chasers, recognition by name + vehicle, area searches, arrests, trackers
- 60 fps measures: adaptive 3D resolution, parked cars sleep, distance culling, cheaper shadows, throttled minimap

## v4 look upgrade
Filmic tone mapping + desaturated, contrasty grade, haze, bloom on night windows and lamps, FXAA, textured asphalt /
concrete (with joints) / grass, grimy building walls, building plinths, setback towers and rooftop units,
glossy car paint with door seams, plates and exhaust, working headlights at night.

## Real models (optional, big quality jump)
Put .glb files in the repo's `assets/` folder (next to the zip): `car_*.glb`, `adams.glb`, `eve.glb`, `ped_*.glb`.
Models are auto-scaled and turned to face forward; add `_flip` to a file name if one faces backwards.
Characters with "walk"/"idle" animations animate automatically. See assets/README.txt.

## Still to port: phone/WAINK, rain, CCTV, clothes, garages and the rest of the roadmap.

## Build the .ipa (free)
1. Push this folder to a GitHub repo; put the separate `codemagic.yaml` in the repo root.
2. codemagic.io -> sign in with GitHub -> Add application -> choose the repo.
3. Start the build "metro-rush-ios". Download `MetroRush-unsigned.ipa` from Artifacts.
4. Install on the iPad with Sideloadly or AltStore using a free Apple ID (needs a Windows PC or Mac; expires after 7 days).
