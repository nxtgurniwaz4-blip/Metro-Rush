# Metro Rush (Godot 4.3): original 3D open-world driving game for iPad

Free toolchain: Godot + Codemagic free tier. No Unity, no Apple developer account, no Mac.
Bundle id: com.Gurniwaz.metrorush. iPad only, landscape, Mobile renderer (Metal).

## In this build
- 8x8-block procedural city (textured towers, parks, roads), fog, day/night cycle, sun shadows
- Two male protagonists (Gurniwaz Singh, Aridaman Virk): walk, SWITCH, enter / exit cars
- Arcade driving with damage, 18 drivable cars, 30 AI traffic cars, 60 pedestrians
- Minimap, speed readout, multi-touch controls (floating joystick, swipe-look, ENTER/EXIT, BRAKE, SWITCH)
- Desktop test keys: WASD, Space = brake, F = enter/exit, Tab = switch

## Coming next (ported from the Unity version)
Car security + lock-picking + alarms + trackers, carjacking, six-star wanted system with witnesses/CCTV/police AI,
phone with WAINK scanner, rain, personalities, and everything else on the roadmap.

## Build the .ipa (free)
1. Push this folder to a GitHub repo; put the separate `codemagic.yaml` in the repo root.
2. codemagic.io -> sign in with GitHub -> Add application -> choose the repo.
3. Start the build "metro-rush-ios". Download `MetroRush-unsigned.ipa` from Artifacts.
4. Install on the iPad with Sideloadly or AltStore using a free Apple ID (needs a Windows PC or Mac; expires after 7 days).
