# Metro Rush (Godot 4.3): original 3D open-world driving game for iPad

Free toolchain: Godot + Codemagic free tier. No Unity, no Apple developer account, no Mac.
Bundle id: com.Gurniwaz.metrorush. iPad only, landscape, Mobile renderer (Metal).

## In this build (v2)
- Protagonists: Adams (male) and Eve (female); SWITCH between them; walk animation
- City built from MultiMeshes (few draw calls): textured towers with lit windows at night, road markings,
  crosswalks, street lamps, parks, sky, fog, day/night cycle, sun shadows
- Better cars (hood, cabin, bumpers, lights, mirrors, rolling/steering wheels, body lean, damage tint, speed FOV)
- Procedural engine sound, 18 drivable cars, 30 traffic cars, 60 walking pedestrians
- Minimap drawn from the grid, speed readout, multi-touch controls, on-screen FPS/camera debug line
- Keyboard + mouse: WASD/arrows move, Shift run, Space brake, F/Enter enter-exit, Tab switch, Q/E or mouse-drag look, wheel zoom

## Still to port: lock-picking, alarms, trackers, carjacking, wanted level + police, phone/WAINK, rain.

## Build the .ipa (free)
1. Push this folder to a GitHub repo; put the separate `codemagic.yaml` in the repo root.
2. codemagic.io -> sign in with GitHub -> Add application -> choose the repo.
3. Start the build "metro-rush-ios". Download `MetroRush-unsigned.ipa` from Artifacts.
4. Install on the iPad with Sideloadly or AltStore using a free Apple ID (needs a Windows PC or Mac; expires after 7 days).
