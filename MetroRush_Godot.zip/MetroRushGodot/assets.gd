class_name Assets
extends RefCounted
# Optional drop-in .glb models in res://assets (see assets/README.txt). Models are auto-scaled,
# centred, put on the ground and turned to face the game's forward direction (-Z).

static var _files: Array[String] = []
static var _scanned := false


static func _scan() -> void:
	if _scanned:
		return
	_scanned = true
	var d := DirAccess.open("res://assets")
	if d == null:
		return
	for f in d.get_files():
		var n: String = f
		if n.ends_with(".import"):
			n = n.trim_suffix(".import")
		elif n.ends_with(".remap"):
			n = n.trim_suffix(".remap")
		var lo := n.to_lower()
		if (lo.ends_with(".glb") or lo.ends_with(".gltf")) and not _files.has(n):
			_files.append(n)


static func files(prefix: String) -> Array[String]:
	_scan()
	var out: Array[String] = []
	for n in _files:
		if n.to_lower().begins_with(prefix):
			out.append(n)
	return out


static func _bounds(n: Node, xf: Transform3D, box: Array) -> void:
	for c in n.get_children():
		var t := xf
		if c is Node3D:
			t = xf * (c as Node3D).transform
		if c is MeshInstance3D:
			var bb: AABB = t * (c as MeshInstance3D).get_aabb()
			if box[1]:
				box[0] = (box[0] as AABB).merge(bb)
			else:
				box[0] = bb
				box[1] = true
		_bounds(c, t, box)


# target = length in metres (cars) or height in metres (people when use_height is true)
static func instance(file: String, target: float, use_height: bool) -> Node3D:
	var res := load("res://assets/" + file)
	if not (res is PackedScene):
		return null
	var model := (res as PackedScene).instantiate() as Node3D
	if model == null:
		return null
	var holder := Node3D.new()
	holder.add_child(model)
	var box: Array = [AABB(), false]
	_bounds(holder, Transform3D.IDENTITY, box)
	if not box[1]:
		holder.free()
		return null
	var bb: AABB = box[0]
	var rot := 180.0
	var s := 1.0
	if use_height:
		s = target / maxf(bb.size.y, 0.001)
	else:
		if bb.size.x > bb.size.z:
			rot += 90.0
		s = target / maxf(maxf(bb.size.x, bb.size.z), 0.001)
	if file.to_lower().contains("_flip"):
		rot += 180.0
	var center := bb.position + bb.size * 0.5
	holder.remove_child(model)
	model.position = Vector3(-center.x, -bb.position.y, -center.z)
	var pivot := Node3D.new()
	pivot.rotation_degrees.y = rot
	pivot.scale = Vector3(s, s, s)
	pivot.add_child(model)
	var wrapper := Node3D.new()
	wrapper.add_child(pivot)
	holder.free()
	return wrapper


static func find_anim(root: Node) -> AnimationPlayer:
	var found := root.find_children("*", "AnimationPlayer", true, false)
	if found.size() > 0:
		return found[0] as AnimationPlayer
	return null


static func pick_anim(ap: AnimationPlayer, keys: Array) -> String:
	for k in keys:
		for a in ap.get_animation_list():
			if String(a).to_lower().contains(String(k)):
				return String(a)
	return ""


static func loop(ap: AnimationPlayer, anim_name: String) -> void:
	if anim_name == "":
		return
	var a := ap.get_animation(anim_name)
	if a != null:
		a.loop_mode = Animation.LOOP_LINEAR


static func set_vis_range(n: Node, d: float) -> void:
	if n is GeometryInstance3D:
		(n as GeometryInstance3D).visibility_range_end = d
	for c in n.get_children():
		set_vis_range(c, d)
