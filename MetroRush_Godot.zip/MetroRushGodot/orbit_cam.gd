class_name OrbitCam
extends Camera3D

var target: Node3D
var yaw := 0.0
var pitch := 0.32
var dist := 5.5
var cur_dist := 5.5
var safe_dist := 99.0


func set_target(t: Node3D, d: float) -> void:
	target = t
	dist = d


func _dir() -> Vector3:
	return Vector3(sin(yaw) * cos(pitch), sin(pitch), cos(yaw) * cos(pitch))


func _physics_process(_d: float) -> void:
	if target == null:
		return
	var focus := target.global_position + Vector3.UP * 1.6
	var q := PhysicsRayQueryParameters3D.create(focus, focus + _dir() * cur_dist)
	if target is CollisionObject3D:
		q.exclude = [(target as CollisionObject3D).get_rid()]
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	if hit.is_empty():
		safe_dist = 99.0
	else:
		var hp: Vector3 = hit["position"]
		safe_dist = maxf(0.8, focus.distance_to(hp) - 0.3)


func _process(delta: float) -> void:
	if target == null:
		return
	var look := Inp.look
	Inp.look = Vector2.ZERO
	yaw -= look.x * 0.005
	pitch = clampf(pitch + look.y * 0.004, 0.05, 1.1)
	if target is Car:
		var c := target as Car
		if absf(c.speed) > 3.0 and look.length() < 0.1:
			yaw = lerp_angle(yaw, c.rotation.y, 1.5 * delta)
	cur_dist = lerpf(cur_dist, dist, 1.0 - exp(-3.0 * delta))
	var focus := target.global_position + Vector3.UP * 1.6
	var use_d := minf(cur_dist, safe_dist)
	var desired := focus + _dir() * use_d
	global_position = global_position.lerp(desired, 1.0 - exp(-12.0 * delta))
	look_at(focus)
