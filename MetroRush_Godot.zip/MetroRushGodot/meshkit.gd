class_name MeshKit
extends RefCounted
# Builds cheap vertex-coloured meshes from boxes/cylinders so a whole car or person is ONE draw call.

static var _cars := {}
static var _peds := {}
static var _wheel: ArrayMesh
static var _shared: StandardMaterial3D


static func vc_material() -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.vertex_color_use_as_albedo = true
	m.roughness = 0.3
	m.metallic = 0.0
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	return m


static func shared_vc() -> StandardMaterial3D:
	if _shared == null:
		_shared = vc_material()
	return _shared


static func _vert(st: SurfaceTool, p: Vector3, n: Vector3, col: Color) -> void:
	st.set_color(col)
	st.set_normal(n)
	st.add_vertex(p)


static func add_box(st: SurfaceTool, c: Vector3, size: Vector3, col: Color) -> void:
	var h := size * 0.5
	var faces := [
		[Vector3(1, 0, 0), Vector3(0, h.y, 0), Vector3(0, 0, h.z)],
		[Vector3(-1, 0, 0), Vector3(0, 0, h.z), Vector3(0, h.y, 0)],
		[Vector3(0, 1, 0), Vector3(0, 0, h.z), Vector3(h.x, 0, 0)],
		[Vector3(0, -1, 0), Vector3(h.x, 0, 0), Vector3(0, 0, h.z)],
		[Vector3(0, 0, 1), Vector3(h.x, 0, 0), Vector3(0, h.y, 0)],
		[Vector3(0, 0, -1), Vector3(0, h.y, 0), Vector3(h.x, 0, 0)]
	]
	for f in faces:
		var n: Vector3 = f[0]
		var u: Vector3 = f[1]
		var v: Vector3 = f[2]
		var fc := c + Vector3(n.x * h.x, n.y * h.y, n.z * h.z)
		var p0 := fc - u - v
		var p1 := fc + u - v
		var p2 := fc + u + v
		var p3 := fc - u + v
		_vert(st, p0, n, col)
		_vert(st, p2, n, col)
		_vert(st, p1, n, col)
		_vert(st, p0, n, col)
		_vert(st, p3, n, col)
		_vert(st, p2, n, col)


static func _tri(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, na: Vector3, nb: Vector3, nc: Vector3, col: Color) -> void:
	_vert(st, a, na, col)
	_vert(st, b, nb, col)
	_vert(st, c, nc, col)


static func add_cyl_x(st: SurfaceTool, c: Vector3, r: float, w: float, col: Color, seg: int) -> void:
	var hw := w * 0.5
	var cr := c + Vector3(hw, 0.0, 0.0)
	var cl := c + Vector3(-hw, 0.0, 0.0)
	for i in range(seg):
		var a0 := TAU * float(i) / float(seg)
		var a1 := TAU * float(i + 1) / float(seg)
		var n0 := Vector3(0.0, sin(a0), cos(a0))
		var n1 := Vector3(0.0, sin(a1), cos(a1))
		var pa := c + n0 * r + Vector3(-hw, 0.0, 0.0)
		var pb := c + n0 * r + Vector3(hw, 0.0, 0.0)
		var pc := c + n1 * r + Vector3(hw, 0.0, 0.0)
		var pd := c + n1 * r + Vector3(-hw, 0.0, 0.0)
		_tri(st, pa, pb, pc, n0, n0, n1, col)
		_tri(st, pa, pc, pd, n0, n1, n1, col)
		_tri(st, cr, pc, pb, Vector3.RIGHT, Vector3.RIGHT, Vector3.RIGHT, col)
		_tri(st, cl, pa, pd, Vector3.LEFT, Vector3.LEFT, Vector3.LEFT, col)


static func car_mesh(color: Color, boxy_wheels: bool) -> ArrayMesh:
	var key := "%s_%s" % [color.to_html(), str(boxy_wheels)]
	if _cars.has(key):
		return _cars[key]
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var dark := Color(0.08, 0.09, 0.11)
	var glass := Color(0.10, 0.15, 0.22)
	add_box(st, Vector3(0.0, 0.55, 0.0), Vector3(1.9, 0.5, 4.3), color)
	add_box(st, Vector3(0.0, 0.88, -1.45), Vector3(1.84, 0.2, 1.3), color)
	add_box(st, Vector3(0.0, 0.88, 1.75), Vector3(1.84, 0.2, 0.8), color)
	add_box(st, Vector3(0.0, 1.1, 0.25), Vector3(1.66, 0.46, 2.1), glass)
	add_box(st, Vector3(0.0, 1.36, 0.25), Vector3(1.72, 0.08, 1.9), color)
	add_box(st, Vector3(0.0, 0.34, -2.2), Vector3(1.92, 0.18, 0.12), dark)
	add_box(st, Vector3(0.0, 0.34, 2.2), Vector3(1.92, 0.18, 0.12), dark)
	add_box(st, Vector3(0.0, 0.62, -2.16), Vector3(1.0, 0.16, 0.06), dark)
	add_box(st, Vector3(-0.66, 0.68, -2.16), Vector3(0.4, 0.15, 0.06), Color(1.0, 0.95, 0.7))
	add_box(st, Vector3(0.66, 0.68, -2.16), Vector3(0.4, 0.15, 0.06), Color(1.0, 0.95, 0.7))
	add_box(st, Vector3(-0.66, 0.68, 2.16), Vector3(0.4, 0.15, 0.06), Color(0.9, 0.1, 0.1))
	add_box(st, Vector3(0.66, 0.68, 2.16), Vector3(0.4, 0.15, 0.06), Color(0.9, 0.1, 0.1))
	add_box(st, Vector3(-1.02, 1.0, -0.5), Vector3(0.14, 0.1, 0.2), color)
	add_box(st, Vector3(1.02, 1.0, -0.5), Vector3(0.14, 0.1, 0.2), color)
	add_box(st, Vector3(-0.955, 0.58, -0.45), Vector3(0.02, 0.44, 0.03), dark)
	add_box(st, Vector3(0.955, 0.58, -0.45), Vector3(0.02, 0.44, 0.03), dark)
	add_box(st, Vector3(-0.955, 0.58, 0.7), Vector3(0.02, 0.44, 0.03), dark)
	add_box(st, Vector3(0.955, 0.58, 0.7), Vector3(0.02, 0.44, 0.03), dark)
	add_box(st, Vector3(0.0, 0.46, -2.18), Vector3(0.5, 0.12, 0.02), Color(0.9, 0.9, 0.9))
	add_box(st, Vector3(0.0, 0.46, 2.18), Vector3(0.5, 0.12, 0.02), Color(0.9, 0.9, 0.9))
	add_box(st, Vector3(0.62, 0.26, 2.2), Vector3(0.1, 0.1, 0.14), Color(0.3, 0.3, 0.32))
	add_box(st, Vector3(0.0, 1.45, 0.9), Vector3(0.03, 0.2, 0.03), dark)
	if boxy_wheels:
		add_box(st, Vector3(-0.9, 0.38, -1.3), Vector3(0.26, 0.76, 0.76), dark)
		add_box(st, Vector3(0.9, 0.38, -1.3), Vector3(0.26, 0.76, 0.76), dark)
		add_box(st, Vector3(-0.9, 0.38, 1.3), Vector3(0.26, 0.76, 0.76), dark)
		add_box(st, Vector3(0.9, 0.38, 1.3), Vector3(0.26, 0.76, 0.76), dark)
	var m := st.commit()
	_cars[key] = m
	return m


static func wheel_mesh() -> ArrayMesh:
	if _wheel != null:
		return _wheel
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	add_cyl_x(st, Vector3.ZERO, 0.38, 0.26, Color(0.05, 0.05, 0.05), 14)
	add_cyl_x(st, Vector3.ZERO, 0.22, 0.28, Color(0.7, 0.72, 0.75), 14)
	_wheel = st.commit()
	return _wheel


static func ped_mesh(shirt: Color, pants: Color, skin: Color, hair: Color) -> ArrayMesh:
	var key := "%s%s%s%s" % [shirt.to_html(), pants.to_html(), skin.to_html(), hair.to_html()]
	if _peds.has(key):
		return _peds[key]
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	add_box(st, Vector3(-0.14, 0.41, 0.0), Vector3(0.2, 0.82, 0.24), pants)
	add_box(st, Vector3(0.14, 0.41, 0.0), Vector3(0.2, 0.82, 0.24), pants)
	add_box(st, Vector3(0.0, 1.13, 0.0), Vector3(0.52, 0.62, 0.3), shirt)
	add_box(st, Vector3(-0.33, 1.1, 0.0), Vector3(0.14, 0.62, 0.16), shirt)
	add_box(st, Vector3(0.33, 1.1, 0.0), Vector3(0.14, 0.62, 0.16), shirt)
	add_box(st, Vector3(0.0, 1.62, 0.0), Vector3(0.28, 0.3, 0.28), skin)
	add_box(st, Vector3(0.0, 1.79, 0.0), Vector3(0.3, 0.1, 0.3), hair)
	var m := st.commit()
	_peds[key] = m
	return m
