class_name Walker
extends AnimatableBody3D
# Follows the road grid forever (traffic in the right-hand lane, pedestrians on the sidewalk).

const DIRS := [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]

var speed := 10.0
var lateral := 3.5
var height := 0.0
var is_ped := false
var visual: Node3D
var ci := 0
var cj := 0
var ti := 0
var tj := 0
var pdi := 0
var pdj := 0
var t := 0.0
var phase := 0.0
var dir := Vector3(0.0, 0.0, -1.0)
var ready_to_walk := false


func start_walk() -> void:
	ci = randi_range(0, City.N)
	cj = randi_range(0, City.N)
	var d: Vector2i = DIRS[randi() % 4]
	pdi = d.x
	pdj = d.y
	_next()
	t = randf() * City.PITCH
	global_position = _ghost()
	rotation.y = atan2(-dir.x, -dir.z)
	ready_to_walk = true


func _next() -> void:
	var opts: Array[Vector2i] = []
	for d in DIRS:
		var ni: int = ci + d.x
		var nj: int = cj + d.y
		if ni < 0 or nj < 0 or ni > City.N or nj > City.N:
			continue
		if d.x == -pdi and d.y == -pdj:
			continue
		opts.append(d)
	if opts.is_empty():
		opts.append(Vector2i(-pdi, -pdj))
	var pick: Vector2i = opts[randi() % opts.size()]
	pdi = pick.x
	pdj = pick.y
	ti = ci + pick.x
	tj = cj + pick.y
	dir = Vector3(pick.x, 0.0, pick.y)


func _ghost() -> Vector3:
	var right := dir.cross(Vector3.UP)
	var p := City.node_pos(ci, cj) + dir * t + right * lateral
	p.y = height
	return p


func _physics_process(delta: float) -> void:
	if not ready_to_walk:
		return
	t += speed * delta
	if t >= City.PITCH:
		t -= City.PITCH
		ci = ti
		cj = tj
		_next()
	var k := 1.0 - exp(-6.0 * delta)
	var np := global_position.lerp(_ghost(), k)
	np.y = height
	global_position = np
	rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), k)
	if is_ped and visual != null:
		phase += speed * delta * 3.2
		visual.position.y = absf(sin(phase)) * 0.05
		visual.rotation.z = sin(phase) * 0.05
