class_name Human
extends RefCounted
# Articulated low-poly person with swinging arms and legs (front faces -Z).


static func _part(parent: Node3D, mesh: Mesh, mat: Material, pos: Vector3) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)
	return mi


static func _limb(parent: Node3D, pivot_pos: Vector3, size: Vector3, mat: Material) -> Node3D:
	var pivot := Node3D.new()
	pivot.position = pivot_pos
	parent.add_child(pivot)
	var bm := BoxMesh.new()
	bm.size = size
	_part(pivot, bm, mat, Vector3(0.0, -size.y * 0.5, 0.0))
	return pivot


static func _box(parent: Node3D, pos: Vector3, size: Vector3, mat: Material) -> void:
	var bm := BoxMesh.new()
	bm.size = size
	_part(parent, bm, mat, pos)


static func build(root: Node3D, shirt: Color, pants: Color, skin: Color, hair: Color, female: bool) -> Dictionary:
	var sm := City.flat(shirt)
	var pm := City.flat(pants)
	var km := City.flat(skin)
	var hm := City.flat(hair)
	var parts := {}
	parts["leg_l"] = _limb(root, Vector3(-0.14, 0.82, 0.0), Vector3(0.2, 0.82, 0.24), pm)
	parts["leg_r"] = _limb(root, Vector3(0.14, 0.82, 0.0), Vector3(0.2, 0.82, 0.24), pm)
	var tw := 0.52
	if female:
		tw = 0.46
	_box(root, Vector3(0.0, 1.13, 0.0), Vector3(tw, 0.62, 0.3), sm)
	parts["arm_l"] = _limb(root, Vector3(-(tw * 0.5 + 0.08), 1.42, 0.0), Vector3(0.14, 0.62, 0.16), sm)
	parts["arm_r"] = _limb(root, Vector3(tw * 0.5 + 0.08, 1.42, 0.0), Vector3(0.14, 0.62, 0.16), sm)

	var head := SphereMesh.new()
	head.radius = 0.16
	head.height = 0.32
	head.radial_segments = 14
	head.rings = 8
	_part(root, head, km, Vector3(0.0, 1.64, 0.0))
	var cap := SphereMesh.new()
	cap.radius = 0.175
	cap.height = 0.2
	cap.radial_segments = 14
	cap.rings = 6
	_part(root, cap, hm, Vector3(0.0, 1.72, 0.01))
	if female:
		_box(root, Vector3(0.0, 1.5, 0.15), Vector3(0.3, 0.5, 0.1), hm)
	var eye := City.flat(Color(0.05, 0.05, 0.05))
	_box(root, Vector3(-0.06, 1.65, -0.15), Vector3(0.04, 0.04, 0.02), eye)
	_box(root, Vector3(0.06, 1.65, -0.15), Vector3(0.04, 0.04, 0.02), eye)
	return parts
