class_name LockPick
extends RefCounted
# Lock-picking minigame: tap PICK (ENTER) while the marker is inside the green zone.

var active := false
var target: Car
var pins := 0
var pin := 0
var fails := 0
var pos := 0.0
var zone_c := 0.5
var zone_h := 0.1
var dir_ := 1.0
var spd := 1.0


func begin(c: Car) -> void:
	target = c
	active = true
	pins = clampi(c.security, 1, 3) + 1
	pin = 0
	fails = 0
	_new_pin()


func _new_pin() -> void:
	pos = 0.0
	dir_ = 1.0
	spd = 0.8 + 0.3 * float(target.security) + 0.08 * float(pin)
	zone_h = maxf(0.04, 0.13 - 0.02 * float(target.security) - 0.008 * float(pin))
	zone_c = randf_range(0.2, 0.8)


# returns 0 = running, 1 = success, 2 = cancelled
func tick(delta: float, player_pos: Vector3) -> int:
	if target == null or not is_instance_valid(target) or target.global_position.distance_to(player_pos) > 6.0:
		active = false
		return 2
	pos += dir_ * spd * delta
	if pos >= 1.0:
		pos = 1.0
		dir_ = -1.0
	elif pos <= 0.0:
		pos = 0.0
		dir_ = 1.0
	if Inp.enter_pressed:
		Inp.enter_pressed = false
		if absf(pos - zone_c) <= zone_h:
			pin += 1
			if pin >= pins:
				active = false
				return 1
			_new_pin()
		else:
			fails += 1
			pin = maxi(0, pin - 1)
			_new_pin()
			if fails == 3 and target.security >= 2:
				target.start_alarm()
			if fails >= 6:
				active = false
				return 2
	return 0
